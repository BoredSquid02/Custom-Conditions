/* ============================================================ */
/* Custom Conditions - Scripting Engine                         */
/* ============================================================ */

/*
 * main.js handles Foundry/module infrastructure.
 *
 * This file handles:
 *
 * - parsing
 * - validation
 * - script execution
 * - damage
 * - healing
 * - temporary HP
 * - arbitrary rolls
 * - saving throws
 * - stacks
 * - mathematical expressions
 * - health checks
 * - AC modifiers
 * - spell save DC modifiers
 * - specific saving throw modifiers
 * - custom and standard Foundry conditions
 * - conditional logic
 * - script documentation
 */


/* ============================================================ */
/* Templates                                                    */
/* ============================================================ */

export function buildStartTurnDamageScript({
  diceCount = 1,
  dieSize = 6,
  damageType = "fire"
} = {}) {
  const count = Math.max(
    1,
    Number.parseInt(diceCount, 10) || 1
  );

  const size = Math.max(
    2,
    Number.parseInt(dieSize, 10) || 6
  );

  const type = String(
    damageType || "fire"
  )
    .trim()
    .toLowerCase();

  return [
    "// Damage at the start of this creature's turn",
    "on startTurn",
    `damage ${count}d${size} ${type}`
  ].join("\n");
}


/* ============================================================ */
/* Trigger helpers                                              */
/* ============================================================ */

function normalizeTrigger(trigger) {
  switch (
    String(trigger)
      .trim()
      .toLowerCase()
  ) {
    case "apply":
      return "apply";

    case "remove":
      return "remove";

    case "startturn":
      return "startTurn";

    case "endturn":
      return "endTurn";

    default:
      return null;
  }
}


function normalizeNumericVariable(variable) {
  switch (
    String(variable)
      .trim()
      .toLowerCase()
  ) {
    case "health":
      return "health";

    case "maxhealth":
      return "maxHealth";

    case "temphp":
      return "tempHP";

    case "missinghealth":
      return "missingHealth";

    case "stack":
    case "stacks":
      return "stacks";

    default:
      return null;
  }
}


/* ============================================================ */
/* Parser                                                       */
/* ============================================================ */

export function parseConditionScript(script) {
  const program = {
    triggers: {
      apply: [],
      remove: [],
      startTurn: [],
      endTurn: []
    },

    errors: []
  };

  const lines = String(
    script ?? ""
  ).split(/\r?\n/);

  let currentTrigger = null;
  const blockStack = [];

  function addInstruction(instruction) {
    if (!currentTrigger) {
      program.errors.push(
        `Line ${instruction.line}: command appears before a trigger.`
      );

      return;
    }

    program.triggers[currentTrigger].push(
      instruction
    );
  }

  for (
    let index = 0;
    index < lines.length;
    index++
  ) {
    const lineNumber = index + 1;
    const line = lines[index].trim();

    /*
     * Blank lines and comments.
     */
    if (
      !line ||
      line.startsWith("//") ||
      line.startsWith("#")
    ) {
      continue;
    }


    /* -------------------------------------------------------- */
    /* Trigger                                                  */
    /* -------------------------------------------------------- */

    const triggerMatch = line.match(
      /^on\s+(apply|remove|startTurn|endTurn)$/i
    );

    if (triggerMatch) {
      if (blockStack.length) {
        program.errors.push(
          `Line ${lineNumber}: an if block before this trigger is missing "end".`
        );

        blockStack.length = 0;
      }

      currentTrigger = normalizeTrigger(
        triggerMatch[1]
      );

      continue;
    }

    if (!currentTrigger) {
      program.errors.push(
        `Line ${lineNumber}: "${line}" appears before an on-trigger.`
      );

      continue;
    }


    /* -------------------------------------------------------- */
    /* Damage per stack                                         */
    /* -------------------------------------------------------- */

    /*
     * Examples:
     *
     * damage 1d6 per @stack fire
     * damage 1d6 + 2 per @stack poison
     * damage 1d4 per @stack
     */
    const damagePerStackMatch = line.match(
      /^damage\s+(.+?)\s+per\s+@stacks?(?:\s+([a-zA-Z][a-zA-Z0-9_-]*))?$/i
    );

    if (damagePerStackMatch) {
      addInstruction({
        type: "damage",
        formula: damagePerStackMatch[1].trim(),

        damageType:
          damagePerStackMatch[2]
            ?.trim()
            .toLowerCase() ??
          null,

        perStack: true,
        line: lineNumber
      });

      continue;
    }


    /* -------------------------------------------------------- */
    /* Typed damage                                             */
    /* -------------------------------------------------------- */

    const damageMatch = line.match(
      /^damage\s+(.+?)\s+([a-zA-Z][a-zA-Z0-9_-]*)$/i
    );

    if (damageMatch) {
      addInstruction({
        type: "damage",
        formula: damageMatch[1].trim(),

        damageType:
          damageMatch[2]
            .trim()
            .toLowerCase(),

        perStack: false,
        line: lineNumber
      });

      continue;
    }


    /* -------------------------------------------------------- */
    /* Untyped damage                                           */
    /* -------------------------------------------------------- */

    const untypedDamageMatch = line.match(
      /^damage\s+(.+)$/i
    );

    if (untypedDamageMatch) {
      addInstruction({
        type: "damage",
        formula: untypedDamageMatch[1].trim(),
        damageType: null,
        perStack: false,
        line: lineNumber
      });

      continue;
    }


    /* -------------------------------------------------------- */
    /* Healing per stack                                        */
    /* -------------------------------------------------------- */

    const healPerStackMatch = line.match(
      /^heal\s+(.+?)\s+per\s+@stacks?$/i
    );

    if (healPerStackMatch) {
      addInstruction({
        type: "heal",
        formula: healPerStackMatch[1].trim(),
        perStack: true,
        line: lineNumber
      });

      continue;
    }


    /* -------------------------------------------------------- */
    /* Healing                                                  */
    /* -------------------------------------------------------- */

    const healMatch = line.match(
      /^heal\s+(.+)$/i
    );

    if (healMatch) {
      addInstruction({
        type: "heal",
        formula: healMatch[1].trim(),
        perStack: false,
        line: lineNumber
      });

      continue;
    }


    /* -------------------------------------------------------- */
    /* Temporary HP per stack                                   */
    /* -------------------------------------------------------- */

    const tempHpPerStackMatch = line.match(
      /^temphp\s+(.+?)\s+per\s+@stacks?$/i
    );

    if (tempHpPerStackMatch) {
      addInstruction({
        type: "tempHP",
        formula: tempHpPerStackMatch[1].trim(),
        perStack: true,
        line: lineNumber
      });

      continue;
    }


    /* -------------------------------------------------------- */
    /* Temporary HP                                             */
    /* -------------------------------------------------------- */

    const tempHpMatch = line.match(
      /^temphp\s+(.+)$/i
    );

    if (tempHpMatch) {
      addInstruction({
        type: "tempHP",
        formula: tempHpMatch[1].trim(),
        perStack: false,
        line: lineNumber
      });

      continue;
    }


    /* -------------------------------------------------------- */
    /* Arbitrary roll per stack                                 */
    /* -------------------------------------------------------- */

    const rollPerStackMatch = line.match(
      /^roll\s+(.+?)\s+per\s+@stacks?$/i
    );

    if (rollPerStackMatch) {
      addInstruction({
        type: "roll",
        formula: rollPerStackMatch[1].trim(),
        perStack: true,
        line: lineNumber
      });

      continue;
    }


    /* -------------------------------------------------------- */
    /* Arbitrary roll                                           */
    /* -------------------------------------------------------- */

    const rollMatch = line.match(
      /^roll\s+(.+)$/i
    );

    if (rollMatch) {
      addInstruction({
        type: "roll",
        formula: rollMatch[1].trim(),
        perStack: false,
        line: lineNumber
      });

      continue;
    }


    /* -------------------------------------------------------- */
    /* Message                                                  */
    /* -------------------------------------------------------- */

    const messageMatch = line.match(
      /^(?:message|chat)\s+(.+)$/i
    );

    if (messageMatch) {
      addInstruction({
        type: "message",
        text: messageMatch[1],
        line: lineNumber
      });

      continue;
    }


    /* -------------------------------------------------------- */
    /* Remove this condition                                    */
    /* -------------------------------------------------------- */

    if (
      /^remove\s+self$/i.test(
        line
      )
    ) {
      addInstruction({
        type: "removeSelf",
        line: lineNumber
      });

      continue;
    }


    /* -------------------------------------------------------- */
    /* Apply another condition                                  */
    /* -------------------------------------------------------- */

    /*
     * This may be:
     *
     * - another Custom Conditions condition
     * - Stunned
     * - Prone
     * - Poisoned
     * - another status registered in CONFIG.statusEffects
     */
    const applyMatch = line.match(
      /^apply\s+(.+)$/i
    );

    if (applyMatch) {
      addInstruction({
        type: "applyCondition",
        conditionName: applyMatch[1].trim(),
        line: lineNumber
      });

      continue;
    }


    /* -------------------------------------------------------- */
    /* Saving throw                                             */
    /* -------------------------------------------------------- */

    /*
     * Examples:
     *
     * save con 14
     * save wis 10 + @stack
     * save dex maxHealth / 4
     */
    const saveMatch = line.match(
      /^save\s+(str|dex|con|int|wis|cha)\s+(.+)$/i
    );

    if (saveMatch) {
      addInstruction({
        type: "save",
        ability: saveMatch[1].toLowerCase(),
        dcExpression: saveMatch[2].trim(),
        line: lineNumber
      });

      continue;
    }


    /* -------------------------------------------------------- */
    /* AC modifier                                              */
    /* -------------------------------------------------------- */

    const acMatch = line.match(
      /^ac\s+(.+)$/i
    );

    if (acMatch) {
      addInstruction({
        type: "modifier",
        modifier: "ac",
        value: acMatch[1].trim(),
        line: lineNumber
      });

      continue;
    }


    /* -------------------------------------------------------- */
    /* Spell save DC modifier                                   */
    /* -------------------------------------------------------- */

    const saveDcMatch = line.match(
      /^saveDC\s+(.+)$/i
    );

    if (saveDcMatch) {
      addInstruction({
        type: "modifier",
        modifier: "saveDC",
        value: saveDcMatch[1].trim(),
        line: lineNumber
      });

      continue;
    }


    /* -------------------------------------------------------- */
    /* Specific saving throw modifier                           */
    /* -------------------------------------------------------- */

    const saveBonusMatch = line.match(
      /^saveBonus\s+(str|dex|con|int|wis|cha)\s+(.+)$/i
    );

    if (saveBonusMatch) {
      addInstruction({
        type: "modifier",
        modifier: "saveBonus",
        ability: saveBonusMatch[1].toLowerCase(),
        value: saveBonusMatch[2].trim(),
        line: lineNumber
      });

      continue;
    }


    /* -------------------------------------------------------- */
    /* Set stacks with an equation                              */
    /* -------------------------------------------------------- */

    const setStacksMatch = line.match(
      /^set\s+stacks\s+(.+)$/i
    );

    if (setStacksMatch) {
      addInstruction({
        type: "setStacks",
        expression: setStacksMatch[1].trim(),
        line: lineNumber
      });

      continue;
    }


    /* -------------------------------------------------------- */
    /* Add stacks with an equation                              */
    /* -------------------------------------------------------- */

    const addStacksMatch = line.match(
      /^add\s+stacks\s+(.+)$/i
    );

    if (addStacksMatch) {
      addInstruction({
        type: "addStacks",
        expression: addStacksMatch[1].trim(),
        line: lineNumber
      });

      continue;
    }


    /* -------------------------------------------------------- */
    /* Remove stacks with an equation                           */
    /* -------------------------------------------------------- */

    const removeStacksMatch = line.match(
      /^remove\s+stacks\s+(.+)$/i
    );

    if (removeStacksMatch) {
      addInstruction({
        type: "removeStacks",
        expression: removeStacksMatch[1].trim(),
        line: lineNumber
      });

      continue;
    }


    /* -------------------------------------------------------- */
    /* Save success                                             */
    /* -------------------------------------------------------- */

    if (
      /^if\s+saveSuccess$/i.test(
        line
      )
    ) {
      addInstruction({
        type: "if",

        condition: {
          type: "saveSuccess"
        },

        line: lineNumber
      });

      blockStack.push("if");

      continue;
    }


    /* -------------------------------------------------------- */
    /* Save failure                                             */
    /* -------------------------------------------------------- */

    if (
      /^if\s+saveFailure$/i.test(
        line
      )
    ) {
      addInstruction({
        type: "if",

        condition: {
          type: "saveFailure"
        },

        line: lineNumber
      });

      blockStack.push("if");

      continue;
    }


    /* -------------------------------------------------------- */
    /* Has condition                                            */
    /* -------------------------------------------------------- */

    /*
     * Works with:
     *
     * if hasCondition Burning
     * if hasCondition Stunned
     * if not hasCondition Prone
     */
    const conditionMatch = line.match(
      /^if\s+(not\s+)?hasCondition\s+(.+)$/i
    );

    if (conditionMatch) {
      addInstruction({
        type: "if",

        condition: {
          type: "hasCondition",
          negate: Boolean(
            conditionMatch[1]
          ),

          conditionName:
            conditionMatch[2].trim()
        },

        line: lineNumber
      });

      blockStack.push("if");

      continue;
    }


    /* -------------------------------------------------------- */
    /* Numeric / health / stack comparison                      */
    /* -------------------------------------------------------- */

    /*
     * Examples:
     *
     * if health = 20
     * if health <= maxHealth / 3
     * if tempHP > 0
     * if missingHealth >= 10
     * if stacks >= 3
     * if stacks >= maxHealth / 20
     */
    const numericConditionMatch = line.match(
      /^if\s+(health|maxHealth|tempHP|missingHealth|stack|stacks)\s*(==|=|!=|>=|<=|>|<)\s*(.+)$/i
    );

    if (numericConditionMatch) {
      const variable = normalizeNumericVariable(
        numericConditionMatch[1]
      );

      addInstruction({
        type: "if",

        condition: {
          type: "numericComparison",
          variable,

          operator:
            numericConditionMatch[2] === "="
              ? "=="
              : numericConditionMatch[2],

          expression:
            numericConditionMatch[3].trim()
        },

        line: lineNumber
      });

      blockStack.push("if");

      continue;
    }


    /* -------------------------------------------------------- */
    /* Else                                                     */
    /* -------------------------------------------------------- */

    if (
      /^else$/i.test(
        line
      )
    ) {
      if (!blockStack.length) {
        program.errors.push(
          `Line ${lineNumber}: "else" has no matching "if".`
        );
      } else {
        addInstruction({
          type: "else",
          line: lineNumber
        });
      }

      continue;
    }


    /* -------------------------------------------------------- */
    /* End                                                      */
    /* -------------------------------------------------------- */

    if (
      /^end$/i.test(
        line
      )
    ) {
      if (!blockStack.length) {
        program.errors.push(
          `Line ${lineNumber}: "end" has no matching "if".`
        );
      } else {
        blockStack.pop();

        addInstruction({
          type: "end",
          line: lineNumber
        });
      }

      continue;
    }


    /* -------------------------------------------------------- */
    /* Unknown                                                  */
    /* -------------------------------------------------------- */

    program.errors.push(
      `Line ${lineNumber}: unknown command "${line}".`
    );
  }


  if (blockStack.length) {
    program.errors.push(
      `One or more if blocks are missing "end".`
    );
  }

  return program;
}


/* ============================================================ */
/* Stack helpers                                                */
/* ============================================================ */

function getStacks(
  effect,
  moduleId
) {
  return Math.max(
    0,

    Number(
      effect?.getFlag?.(
        moduleId,
        "stacks"
      ) ?? 0
    )
  );
}


function replaceStackToken(
  text,
  stacks
) {
  return String(
    text ?? ""
  ).replace(
    /@stacks?\b/gi,
    String(stacks)
  );
}


/*
 * At 3 stacks:
 *
 * damage 1d6 per @stack
 *
 * becomes:
 *
 * (1d6) + (1d6) + (1d6)
 */
function buildPerStackFormula(
  formula,
  stacks
) {
  const count = Math.max(
    0,
    Math.trunc(
      Number(stacks) || 0
    )
  );

  if (count <= 0) {
    return "0";
  }

  return Array.from(
    {
      length: count
    },

    () =>
      `(${formula})`
  ).join(
    " + "
  );
}


function resolveRollFormula(
  formula,
  effect,
  moduleId,
  perStack = false
) {
  const stacks =
    getStacks(
      effect,
      moduleId
    );

  if (perStack) {
    return buildPerStackFormula(
      formula,
      stacks
    );
  }

  return formula;
}


/* ============================================================ */
/* Health and equation helpers                                  */
/* ============================================================ */

function getActorHealthValues(
  actor
) {
  const hp =
    actor?.system
      ?.attributes
      ?.hp ??
    {};

  const health =
    Number(
      hp.value ?? 0
    ) || 0;

  const maxHealth =
    Number(
      hp.effectiveMax ??
      hp.max ??
      health
    ) || 0;

  const tempHP =
    Number(
      hp.temp ?? 0
    ) || 0;

  const missingHealth =
    Math.max(
      0,
      maxHealth - health
    );

  return {
    health,
    maxHealth,
    tempHP,
    missingHealth
  };
}


function getMathValues(
  actor,
  effect,
  moduleId
) {
  const healthValues =
    getActorHealthValues(
      actor
    );

  const stacks =
    getStacks(
      effect,
      moduleId
    );

  return {
    ...healthValues,

    stack:
      stacks,

    stacks
  };
}


function replaceMathVariables(
  expression,
  values
) {
  let text =
    String(
      expression ?? ""
    );

  /*
   * @stack / @stacks
   */
  text = text.replace(
    /@stacks?\b/gi,
    String(
      values.stacks ?? 0
    )
  );

  /*
   * Long names first so "health" doesn't
   * interfere with "maxHealth", etc.
   */
  text = text.replace(
    /\bmissingHealth\b/gi,
    String(
      values.missingHealth ?? 0
    )
  );

  text = text.replace(
    /\bmaxHealth\b/gi,
    String(
      values.maxHealth ?? 0
    )
  );

  text = text.replace(
    /\btempHP\b/gi,
    String(
      values.tempHP ?? 0
    )
  );

  text = text.replace(
    /\bhealth\b/gi,
    String(
      values.health ?? 0
    )
  );

  text = text.replace(
    /\bstacks?\b/gi,
    String(
      values.stacks ?? 0
    )
  );

  return text;
}


function evaluateArithmeticText(
  text,
  originalExpression = text
) {
  const expression =
    String(
      text ?? ""
    ).trim();

  if (!expression) {
    throw new Error(
      `math expression "${originalExpression}" is empty.`
    );
  }

  /*
   * Once all supported variables have
   * been replaced, only arithmetic remains.
   */
  if (
    !/^[0-9+\-*/().\s]+$/.test(
      expression
    )
  ) {
    throw new Error(
      `math expression "${originalExpression}" contains an unknown variable or unsupported character.`
    );
  }

  let result;

  try {
    result = Function(
      `"use strict"; return (${expression});`
    )();
  } catch {
    throw new Error(
      `math expression "${originalExpression}" could not be evaluated.`
    );
  }

  const number =
    Number(
      result
    );

  if (
    !Number.isFinite(
      number
    )
  ) {
    throw new Error(
      `math expression "${originalExpression}" did not produce a finite number.`
    );
  }

  return number;
}


function evaluateMathExpression(
  expression,
  values
) {
  const replaced =
    replaceMathVariables(
      expression,
      values
    );

  return evaluateArithmeticText(
    replaced,
    expression
  );
}


/*
 * Persistent modifiers intentionally only
 * support @stack as a variable.
 *
 * That is because they automatically refresh
 * when stack count changes, whereas a modifier
 * depending on current HP would require watching
 * every HP update.
 */
function evaluateModifierExpression(
  expression,
  stacks
) {
  const text =
    replaceStackToken(
      expression,
      stacks
    );

  return evaluateArithmeticText(
    text,
    expression
  );
}


function stackInteger(
  number
) {
  /*
   * Stack counts are always whole numbers.
   * Math.trunc rounds toward zero:
   *
   * 3.8 -> 3
   * -3.8 -> -3
   */
  return Math.trunc(
    Number(number) || 0
  );
}


/* ============================================================ */
/* Validation                                                   */
/* ============================================================ */

export function validateConditionScript(
  script
) {
  const program =
    parseConditionScript(
      script
    );

  const sampleMathValues = {
    health: 20,
    maxHealth: 60,
    tempHP: 5,
    missingHealth: 40,
    stack: 2,
    stacks: 2
  };

  for (
    const instructions of
      Object.values(
        program.triggers
      )
  ) {
    for (
      const instruction of
        instructions
    ) {
      /*
       * Validate roll formulas.
       */
      if (
        [
          "damage",
          "heal",
          "tempHP",
          "roll"
        ].includes(
          instruction.type
        )
      ) {
        /*
         * @stack inside the actual formula is
         * intentionally discouraged. Use:
         *
         * damage 1d6 per @stack fire
         *
         * instead of:
         *
         * damage 1d6 + @stack fire
         */
        if (
          /@stacks?\b/i.test(
            instruction.formula
          )
        ) {
          program.errors.push(
            `Line ${instruction.line}: use "per @stack" for stack-scaled rolls rather than placing @stack inside the roll formula.`
          );
        } else if (
          typeof Roll?.validate ===
            "function" &&
          !Roll.validate(
            instruction.formula
          )
        ) {
          program.errors.push(
            `Line ${instruction.line}: "${instruction.formula}" is not a valid roll formula.`
          );
        }
      }


      /*
       * Validate damage type.
       */
      if (
        instruction.type ===
          "damage" &&
        instruction.damageType
      ) {
        const damageTypes =
          CONFIG.DND5E
            ?.damageTypes ??
          {};

        if (
          Object.keys(
            damageTypes
          ).length &&
          !Object.hasOwn(
            damageTypes,
            instruction.damageType
          )
        ) {
          program.errors.push(
            `Line ${instruction.line}: "${instruction.damageType}" is not a recognized damage type.`
          );
        }
      }


      /*
       * Validate AC / save DC / save bonus math.
       */
      if (
        instruction.type ===
        "modifier"
      ) {
        try {
          evaluateModifierExpression(
            instruction.value,
            2
          );
        } catch (err) {
          program.errors.push(
            `Line ${instruction.line}: ${err.message}`
          );
        }
      }


      /*
       * Validate stack equations.
       */
      if (
        [
          "setStacks",
          "addStacks",
          "removeStacks"
        ].includes(
          instruction.type
        )
      ) {
        try {
          evaluateMathExpression(
            instruction.expression,
            sampleMathValues
          );
        } catch (err) {
          program.errors.push(
            `Line ${instruction.line}: ${err.message}`
          );
        }
      }


      /*
       * Validate save DC equation.
       */
      if (
        instruction.type ===
        "save"
      ) {
        try {
          evaluateMathExpression(
            instruction.dcExpression,
            sampleMathValues
          );
        } catch (err) {
          program.errors.push(
            `Line ${instruction.line}: invalid save DC: ${err.message}`
          );
        }
      }


      /*
       * Validate health/stack comparison equation.
       */
      if (
        instruction.type ===
          "if" &&
        instruction.condition
          ?.type ===
          "numericComparison"
      ) {
        try {
          evaluateMathExpression(
            instruction.condition
              .expression,
            sampleMathValues
          );
        } catch (err) {
          program.errors.push(
            `Line ${instruction.line}: invalid comparison: ${err.message}`
          );
        }
      }
    }
  }

  return {
    ok:
      program.errors.length ===
      0,

    errors:
      program.errors,

    program
  };
}


/* ============================================================ */
/* Stack display                                                */
/* ============================================================ */

async function updateDisplayedStackName(
  effect,
  moduleId,
  stacks,
  conditionName
) {
  const baseName =
    effect.getFlag?.(
      moduleId,
      "baseName"
    ) ||
    conditionName ||
    String(
      effect.name ??
      "Condition"
    ).replace(
      /\s+\[\d+\]$/,
      ""
    );

  const name =
    stacks > 0
      ? `${baseName} [${stacks}]`
      : baseName;

  await effect.update({
    name,

    [`flags.${moduleId}.stacks`]:
      stacks,

    [`flags.${moduleId}.baseName`]:
      baseName
  });
}


async function setStacks(
  effect,
  moduleId,
  value,
  context
) {
  const stacks =
    Math.max(
      0,
      stackInteger(
        value
      )
    );

  await updateDisplayedStackName(
    effect,
    moduleId,
    stacks,
    context?.condition?.name
  );

  if (context) {
    await refreshDynamicModifiers(
      context,
      stacks
    );
  }

  return stacks;
}


/* ============================================================ */
/* Foundry roll data                                            */
/* ============================================================ */

function getRollData(
  actor
) {
  return (
    actor.getRollData?.() ??
    {}
  );
}


/* ============================================================ */
/* Saving throws                                                */
/* ============================================================ */

async function rollSavingThrow(
  actor,
  ability,
  dc,
  condition
) {
  let roll = null;

  /*
   * Try D&D5e's supplied roll methods first.
   */
  if (
    typeof actor.rollAbilitySave ===
    "function"
  ) {
    try {
      roll =
        await actor.rollAbilitySave(
          ability,
          {
            fastForward: true
          }
        );
    } catch (err) {
      console.warn(
        "Custom Conditions | rollAbilitySave failed; using fallback.",
        err
      );
    }
  }


  if (
    !roll &&
    typeof actor.rollSavingThrow ===
      "function"
  ) {
    try {
      roll =
        await actor.rollSavingThrow({
          ability,
          target: dc
        });
    } catch (err) {
      console.warn(
        "Custom Conditions | rollSavingThrow failed; using fallback.",
        err
      );
    }
  }


  if (
    Array.isArray(
      roll
    )
  ) {
    roll =
      roll[0] ??
      null;
  }


  let total =
    Number(
      roll?.total ??
      roll?.roll?.total
    );


  /*
   * Generic fallback.
   */
  if (
    !Number.isFinite(
      total
    )
  ) {
    const abilityData =
      actor.system
        ?.abilities
        ?.[ability];

    const candidates = [
      abilityData
        ?.save
        ?.value,

      abilityData
        ?.save
        ?.total,

      abilityData
        ?.save,

      abilityData
        ?.mod
    ];

    let bonus = 0;

    for (
      const candidate of
        candidates
    ) {
      if (
        Number.isFinite(
          Number(
            candidate
          )
        )
      ) {
        bonus =
          Number(
            candidate
          );

        break;
      }
    }

    roll =
      await new Roll(
        `1d20 + ${bonus}`
      ).evaluate();

    await roll.toMessage({
      speaker:
        ChatMessage.getSpeaker({
          actor
        }),

      flavor:
        `${condition.name}: ` +
        `${ability.toUpperCase()} save vs DC ${dc}`
    });

    total =
      Number(
        roll.total ??
        0
      );
  }


  return {
    ability,
    dc,
    total,

    success:
      total >= dc
  };
}


/* ============================================================ */
/* Damage                                                       */
/* ============================================================ */

async function rollDamage({
  actor,
  token,
  effect,
  condition,
  moduleId,
  formula,
  damageType,
  perStack
}) {
  const resolvedFormula =
    resolveRollFormula(
      formula,
      effect,
      moduleId,
      perStack
    );

  const roll =
    await new Roll(
      resolvedFormula,
      getRollData(actor)
    ).evaluate();

  await roll.toMessage({
    speaker:
      ChatMessage.getSpeaker({
        actor,

        token:
          token?.object ??
          token ??
          null
      }),

    flavor:
      `${condition.name}: ` +
      `${damageType ? `${damageType} ` : ""}` +
      `damage`
  });

  const amount =
    Number(
      roll.total
    ) || 0;


  if (
    typeof actor.applyDamage ===
    "function"
  ) {
    const damagePart = {
      value: amount
    };

    if (damageType) {
      damagePart.type =
        damageType;
    }

    await actor.applyDamage([
      damagePart
    ]);

    return roll;
  }


  /*
   * Generic fallback.
   */
  const hp =
    actor.system
      ?.attributes
      ?.hp;

  if (hp) {
    await actor.update({
      "system.attributes.hp.value":
        Math.max(
          0,
          Number(
            hp.value
          ) - amount
        )
    });
  }

  return roll;
}


/* ============================================================ */
/* Healing                                                      */
/* ============================================================ */

async function rollHealing({
  actor,
  token,
  effect,
  condition,
  moduleId,
  formula,
  perStack
}) {
  const resolvedFormula =
    resolveRollFormula(
      formula,
      effect,
      moduleId,
      perStack
    );

  const roll =
    await new Roll(
      resolvedFormula,
      getRollData(actor)
    ).evaluate();

  await roll.toMessage({
    speaker:
      ChatMessage.getSpeaker({
        actor,

        token:
          token?.object ??
          token ??
          null
      }),

    flavor:
      `${condition.name}: healing`
  });

  const amount =
    Math.max(
      0,
      Number(
        roll.total
      ) || 0
    );


  if (
    typeof actor.applyDamage ===
    "function"
  ) {
    try {
      await actor.applyDamage([
        {
          value: amount,
          type: "healing"
        }
      ]);

      return roll;
    } catch (err) {
      console.warn(
        "Custom Conditions | Healing through applyDamage failed; using HP fallback.",
        err
      );
    }
  }


  const hp =
    actor.system
      ?.attributes
      ?.hp;

  if (hp) {
    const maximum =
      Number(
        hp.effectiveMax ??
        hp.max ??
        hp.value
      );

    await actor.update({
      "system.attributes.hp.value":
        Math.min(
          maximum,
          Number(
            hp.value
          ) + amount
        )
    });
  }

  return roll;
}


/* ============================================================ */
/* Temporary Hit Points                                         */
/* ============================================================ */

async function rollTemporaryHP({
  actor,
  token,
  effect,
  condition,
  moduleId,
  formula,
  perStack
}) {
  const resolvedFormula =
    resolveRollFormula(
      formula,
      effect,
      moduleId,
      perStack
    );

  const roll =
    await new Roll(
      resolvedFormula,
      getRollData(actor)
    ).evaluate();

  await roll.toMessage({
    speaker:
      ChatMessage.getSpeaker({
        actor,

        token:
          token?.object ??
          token ??
          null
      }),

    flavor:
      `${condition.name}: temporary hit points`
  });

  const amount =
    Math.max(
      0,
      Number(
        roll.total
      ) || 0
    );

  const hp =
    actor.system
      ?.attributes
      ?.hp;

  if (!hp) {
    return roll;
  }


  /*
   * Temporary HP does not stack.
   * Keep whichever value is higher.
   */
  await actor.update({
    "system.attributes.hp.temp":
      Math.max(
        Number(
          hp.temp ??
          0
        ),

        amount
      )
  });

  return roll;
}


/* ============================================================ */
/* Generic automatic roll                                       */
/* ============================================================ */

async function makeAutomaticRoll({
  actor,
  token,
  effect,
  condition,
  moduleId,
  formula,
  perStack
}) {
  const resolvedFormula =
    resolveRollFormula(
      formula,
      effect,
      moduleId,
      perStack
    );

  const roll =
    await new Roll(
      resolvedFormula,
      getRollData(actor)
    ).evaluate();

  await roll.toMessage({
    speaker:
      ChatMessage.getSpeaker({
        actor,

        token:
          token?.object ??
          token ??
          null
      }),

    flavor:
      `${condition.name}: automatic roll`
  });

  return roll;
}


/* ============================================================ */
/* Custom + Foundry condition lookup                            */
/* ============================================================ */

function normalizeConditionName(
  value
) {
  return String(
    value ?? ""
  )
    .trim()
    .toLowerCase()
    .replace(
      /\s+/g,
      " "
    );
}


function localizeStatusText(
  value
) {
  const raw =
    String(
      value ?? ""
    );

  if (!raw) {
    return "";
  }

  try {
    return game.i18n.localize(
      raw
    );
  } catch {
    return raw;
  }
}


function statusDefinitionNames(
  status
) {
  const names =
    new Set();

  const add =
    (value) => {
      if (
        value ===
          undefined ||
        value ===
          null
      ) {
        return;
      }

      const raw =
        String(value)
          .trim();

      if (!raw) {
        return;
      }

      names.add(
        normalizeConditionName(
          raw
        )
      );

      names.add(
        normalizeConditionName(
          localizeStatusText(
            raw
          )
        )
      );
    };

  add(status?.id);
  add(status?.name);
  add(status?.label);

  return names;
}


function findStandardStatusDefinition(
  conditionName
) {
  const targetName =
    normalizeConditionName(
      conditionName
    );

  if (!targetName) {
    return null;
  }

  return (
    Array.from(
      CONFIG.statusEffects ??
      []
    ).find(
      (status) =>
        statusDefinitionNames(
          status
        ).has(
          targetName
        )
    ) ??
    null
  );
}


function getStatusDisplayName(
  status
) {
  const localizedName =
    localizeStatusText(
      status?.name ??
      status?.label ??
      ""
    );

  if (
    localizedName &&
    !localizedName.includes(
      "."
    )
  ) {
    return localizedName;
  }

  return (
    localizedName ||
    String(
      status?.id ??
      "Condition"
    )
  );
}


function effectHasStatusId(
  effect,
  statusId
) {
  return Boolean(
    effect?.statuses
      ?.has?.(
        statusId
      )
  );
}


function actorHasNamedCondition(
  actor,
  conditionName,
  context
) {
  const targetName =
    normalizeConditionName(
      conditionName
    );

  if (!targetName) {
    return false;
  }


  /*
   * First check conditions created by
   * this module.
   */
  const customCondition =
    context
      .getConditions()
      .find(
        (condition) =>
          normalizeConditionName(
            condition.name
          ) ===
          targetName
      );

  if (customCondition) {
    return Array.from(
      actor.effects ??
      []
    ).some(
      (effect) =>
        effect.statuses
          ?.has?.(
            customCondition.id
          ) ||

        effect.getFlag?.(
          context.moduleId,
          "conditionId"
        ) ===
          customCondition.id
    );
  }


  /*
   * Then check ordinary Foundry/D&D5e
   * status effects such as Stunned,
   * Poisoned, Prone, Restrained, etc.
   */
  const standardStatus =
    findStandardStatusDefinition(
      conditionName
    );

  if (standardStatus?.id) {
    return Array.from(
      actor.effects ??
      []
    ).some(
      (effect) =>
        effectHasStatusId(
          effect,
          standardStatus.id
        )
    );
  }


  /*
   * Last-resort fallback:
   * compare directly against effect names
   * and status IDs.
   *
   * This can help with statuses supplied by
   * another module which do not have an
   * ordinary CONFIG.statusEffects entry.
   */
  return Array.from(
    actor.effects ??
    []
  ).some(
    (effect) => {
      if (
        normalizeConditionName(
          effect.name
        ) ===
        targetName
      ) {
        return true;
      }

      for (
        const statusId of
          effect.statuses ??
          []
      ) {
        if (
          normalizeConditionName(
            statusId
          ) ===
          targetName
        ) {
          return true;
        }
      }

      return false;
    }
  );
}


async function applyStandardStatus(
  actor,
  status
) {
  if (
    !actor ||
    !status?.id
  ) {
    return null;
  }


  /*
   * Don't duplicate an existing status.
   */
  const existing =
    Array.from(
      actor.effects ??
      []
    ).find(
      (effect) =>
        effectHasStatusId(
          effect,
          status.id
        )
    );

  if (existing) {
    return existing;
  }


  const effectData = {
    name:
      getStatusDisplayName(
        status
      ),

    img:
      status.img ??
      status.icon ??
      "icons/svg/aura.svg",

    statuses: [
      status.id
    ]
  };


  /*
   * If a system/module status definition
   * provides extra ActiveEffect information,
   * carry it over.
   */
  if (
    Array.isArray(
      status.changes
    )
  ) {
    effectData.changes =
      foundry.utils.deepClone(
        status.changes
      );
  }

  if (status.duration) {
    effectData.duration =
      foundry.utils.deepClone(
        status.duration
      );
  }

  if (status.flags) {
    effectData.flags =
      foundry.utils.deepClone(
        status.flags
      );
  }

  if (status.description) {
    effectData.description =
      status.description;
  }


  const created =
    await actor.createEmbeddedDocuments(
      "ActiveEffect",
      [
        effectData
      ]
    );

  return (
    created[0] ??
    null
  );
}


async function applyNamedCondition(
  actor,
  conditionName,
  context
) {
  const targetName =
    normalizeConditionName(
      conditionName
    );


  /*
   * Custom Conditions entries take priority.
   */
  const customCondition =
    context
      .getConditions()
      .find(
        (condition) =>
          normalizeConditionName(
            condition.name
          ) ===
          targetName
      );

  if (customCondition) {
    return context.applyCondition(
      actor,
      customCondition
    );
  }


  /*
   * Otherwise try Foundry/D&D5e status effects.
   */
  const standardStatus =
    findStandardStatusDefinition(
      conditionName
    );

  if (standardStatus) {
    return applyStandardStatus(
      actor,
      standardStatus
    );
  }


  ui.notifications.warn(
    `Condition "${conditionName}" could not be found as either a custom condition or a Foundry status condition.`
  );

  return null;
}


/* ============================================================ */
/* Conditional logic                                            */
/* ============================================================ */

function compareNumbers(
  left,
  operator,
  right
) {
  switch (operator) {
    case "==":
      return left === right;

    case "!=":
      return left !== right;

    case ">":
      return left > right;

    case "<":
      return left < right;

    case ">=":
      return left >= right;

    case "<=":
      return left <= right;

    default:
      return false;
  }
}


async function evaluateScriptCondition(
  condition,
  context
) {
  switch (
    condition.type
  ) {
    case "saveSuccess":
      return Boolean(
        context.lastSave
          ?.success
      );


    case "saveFailure":
      return (
        context.lastSave !=
          null &&
        !context.lastSave
          .success
      );


    case "hasCondition": {
      const result =
        actorHasNamedCondition(
          context.actor,
          condition.conditionName,
          context
        );

      return condition.negate
        ? !result
        : result;
    }


    case "numericComparison": {
      const values =
        getMathValues(
          context.actor,
          context.effect,
          context.moduleId
        );

      const left =
        Number(
          values[
            condition.variable
          ] ?? 0
        );

      const right =
        evaluateMathExpression(
          condition.expression,
          values
        );

      return compareNumbers(
        left,
        condition.operator,
        right
      );
    }


    default:
      return false;
  }
}


/* ============================================================ */
/* Active Effect modifiers                                      */
/* ============================================================ */

function modifierKey(
  kind,
  ability = null
) {
  switch (kind) {
    case "ac":
      return (
        "system.attributes.ac.bonus"
      );


    case "saveDC":
      return (
        "system.bonuses.spell.dc"
      );


    case "saveBonus": {
      if (!ability) {
        return null;
      }

      return (
        `system.abilities.${ability}.bonuses.save`
      );
    }


    default:
      return null;
  }
}


async function setEffectModifier(
  effect,
  kind,
  expression,
  stacks,
  ability = null
) {
  /*
   * Important:
   *
   * saveBonus needs the chosen ability to
   * reach modifierKey().
   */
  const key =
    modifierKey(
      kind,
      ability
    );

  if (!key) {
    throw new Error(
      `Unknown modifier type "${kind}".`
    );
  }


  const amount =
    evaluateModifierExpression(
      expression,
      stacks
    );


  const changes =
    foundry.utils.deepClone(
      effect.changes ??
      []
    );


  const existing =
    changes.find(
      (change) =>
        change.key === key
    );


  if (existing) {
    existing.mode =
      CONST
        .ACTIVE_EFFECT_MODES
        .ADD;

    existing.value =
      String(
        amount
      );

    existing.priority ??=
      20;
  } else {
    changes.push({
      key,

      mode:
        CONST
          .ACTIVE_EFFECT_MODES
          .ADD,

      value:
        String(
          amount
        ),

      priority:
        20
    });
  }


  await effect.update({
    changes
  });
}


/*
 * Recalculate persistent modifiers whenever
 * the stack count changes.
 *
 * We use modifiers in the "on apply" section
 * because those are intended to remain in
 * effect for the life of the condition.
 */
async function refreshDynamicModifiers(
  context,
  knownStacks = null
) {
  if (
    !context?.effect ||
    !context?.condition
  ) {
    return;
  }


  const validation =
    validateConditionScript(
      context.condition
        .script ??
      ""
    );

  if (!validation.ok) {
    return;
  }


  const stacks =
    knownStacks ??
    getStacks(
      context.effect,
      context.moduleId
    );


  const modifiers =
    validation
      .program
      .triggers
      .apply
      .filter(
        (instruction) =>
          instruction.type ===
          "modifier"
      );


  for (
    const instruction of
      modifiers
  ) {
    await setEffectModifier(
      context.effect,
      instruction.modifier,
      instruction.value,
      stacks,
      instruction.ability ??
        null
    );
  }
}


/* ============================================================ */
/* Execute one instruction                                      */
/* ============================================================ */

async function executeInstruction(
  instruction,
  context
) {
  switch (
    instruction.type
  ) {
    case "damage": {
      await rollDamage({
        actor:
          context.actor,

        token:
          context.token,

        effect:
          context.effect,

        condition:
          context.condition,

        moduleId:
          context.moduleId,

        formula:
          instruction.formula,

        damageType:
          instruction.damageType,

        perStack:
          instruction.perStack
      });

      return {};
    }


    case "heal": {
      await rollHealing({
        actor:
          context.actor,

        token:
          context.token,

        effect:
          context.effect,

        condition:
          context.condition,

        moduleId:
          context.moduleId,

        formula:
          instruction.formula,

        perStack:
          instruction.perStack
      });

      return {};
    }


    case "tempHP": {
      await rollTemporaryHP({
        actor:
          context.actor,

        token:
          context.token,

        effect:
          context.effect,

        condition:
          context.condition,

        moduleId:
          context.moduleId,

        formula:
          instruction.formula,

        perStack:
          instruction.perStack
      });

      return {};
    }


    case "roll": {
      await makeAutomaticRoll({
        actor:
          context.actor,

        token:
          context.token,

        effect:
          context.effect,

        condition:
          context.condition,

        moduleId:
          context.moduleId,

        formula:
          instruction.formula,

        perStack:
          instruction.perStack
      });

      return {};
    }


    case "message": {
      await ChatMessage.create({
        speaker:
          ChatMessage.getSpeaker({
            actor:
              context.actor,

            token:
              context.token
                ?.object ??
              context.token ??
              null
          }),

        flavor:
          context.condition
            .name,

        content:
          `<p>${escapeHtml(
            instruction.text
          )}</p>`
      });

      return {};
    }


    case "save": {
      const values =
        getMathValues(
          context.actor,
          context.effect,
          context.moduleId
        );

      const dc =
        Math.max(
          0,

          stackInteger(
            evaluateMathExpression(
              instruction.dcExpression,
              values
            )
          )
        );

      context.lastSave =
        await rollSavingThrow(
          context.actor,
          instruction.ability,
          dc,
          context.condition
        );

      return {};
    }


    case "modifier": {
      await setEffectModifier(
        context.effect,
        instruction.modifier,
        instruction.value,

        getStacks(
          context.effect,
          context.moduleId
        ),

        instruction.ability ??
          null
      );

      return {};
    }


    case "setStacks": {
      const values =
        getMathValues(
          context.actor,
          context.effect,
          context.moduleId
        );

      const amount =
        evaluateMathExpression(
          instruction.expression,
          values
        );

      await setStacks(
        context.effect,
        context.moduleId,
        amount,
        context
      );

      return {};
    }


    case "addStacks": {
      const current =
        getStacks(
          context.effect,
          context.moduleId
        );

      const values =
        getMathValues(
          context.actor,
          context.effect,
          context.moduleId
        );

      const amount =
        stackInteger(
          evaluateMathExpression(
            instruction.expression,
            values
          )
        );

      await setStacks(
        context.effect,
        context.moduleId,
        current + amount,
        context
      );

      return {};
    }


    case "removeStacks": {
      const current =
        getStacks(
          context.effect,
          context.moduleId
        );

      const values =
        getMathValues(
          context.actor,
          context.effect,
          context.moduleId
        );

      const amount =
        Math.abs(
          stackInteger(
            evaluateMathExpression(
              instruction.expression,
              values
            )
          )
        );

      await setStacks(
        context.effect,
        context.moduleId,
        current - amount,
        context
      );

      return {};
    }


    case "applyCondition": {
      await applyNamedCondition(
        context.actor,
        instruction.conditionName,
        context
      );

      return {};
    }


    case "removeSelf": {
      /*
       * Don't recursively remove the effect
       * from its own remove trigger.
       */
      if (
        context.trigger !==
        "remove"
      ) {
        await context.effect.delete();

        return {
          stop: true
        };
      }

      return {};
    }


    default:
      return {};
  }
}


/* ============================================================ */
/* Execute script                                               */
/* ============================================================ */

export async function executeConditionScript({
  moduleId,
  actor,
  token = null,
  effect,
  condition,
  trigger,
  getConditions,
  applyCondition
}) {
  if (
    !actor ||
    !effect ||
    !condition
  ) {
    return;
  }


  const validation =
    validateConditionScript(
      condition.script ??
      ""
    );


  if (!validation.ok) {
    throw new Error(
      validation.errors.join(
        " | "
      )
    );
  }


  /*
   * Internal pseudo-trigger used by main.js
   * whenever someone manually changes stacks.
   *
   * Do not execute ordinary on-apply actions.
   * Only recalculate stack-dependent persistent
   * modifiers.
   */
  if (
    trigger ===
    "stackChange"
  ) {
    await refreshDynamicModifiers(
      {
        moduleId,
        actor,
        token,
        effect,
        condition,
        getConditions,
        applyCondition
      }
    );

    return;
  }


  const instructions =
    validation
      .program
      .triggers
      [trigger] ??
    [];


  if (!instructions.length) {
    return;
  }


  const context = {
    moduleId,
    actor,
    token,
    effect,
    condition,
    trigger,
    getConditions,
    applyCondition,

    lastSave:
      null,

    executing:
      true,

    branches:
      []
  };


  for (
    const instruction of
      instructions
  ) {
    /* -------------------------------------------------------- */
    /* IF                                                       */
    /* -------------------------------------------------------- */

    if (
      instruction.type ===
      "if"
    ) {
      const result =
        await evaluateScriptCondition(
          instruction.condition,
          context
        );

      context.branches.push({
        parentExecuting:
          context.executing,

        conditionResult:
          result
      });

      context.executing =
        context.executing &&
        result;

      continue;
    }


    /* -------------------------------------------------------- */
    /* ELSE                                                     */
    /* -------------------------------------------------------- */

    if (
      instruction.type ===
      "else"
    ) {
      const branch =
        context.branches.at(
          -1
        );

      if (!branch) {
        continue;
      }

      context.executing =
        branch.parentExecuting &&
        !branch.conditionResult;

      continue;
    }


    /* -------------------------------------------------------- */
    /* END                                                      */
    /* -------------------------------------------------------- */

    if (
      instruction.type ===
      "end"
    ) {
      const branch =
        context.branches.pop();

      context.executing =
        branch
          ?.parentExecuting ??
        true;

      continue;
    }


    if (
      !context.executing
    ) {
      continue;
    }


    const result =
      await executeInstruction(
        instruction,
        context
      );


    if (
      result?.stop
    ) {
      break;
    }
  }
}


/* ============================================================ */
/* HTML escaping                                                */
/* ============================================================ */

function escapeHtml(value) {
  return String(
    value ?? ""
  )
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}


/* ============================================================ */
/* Script Commands guide                                        */
/* ============================================================ */

export function openScriptHelp() {
  const sectionStyle = `
    scroll-margin-top: 8px;
    margin-bottom: 24px;
  `;

  const headingStyle = `
    margin-top: 0;
    padding-bottom: 4px;
    border-bottom: 1px solid var(--color-border-light-primary);
  `;

  const noteStyle = `
    padding: 8px 10px;
    margin: 8px 0;
    border-left: 3px solid var(--color-border-highlight);
    background: rgba(0, 0, 0, 0.06);
  `;

  const content = `
    <div
      class="cc-script-guide"
      style="
        display: grid;
        grid-template-columns: 190px minmax(0, 1fr);
        gap: 14px;
        height: 650px;
      "
    >

      <!-- ================================================== -->
      <!-- Sidebar                                            -->
      <!-- ================================================== -->

      <aside
        style="
          overflow-y: auto;
          padding-right: 10px;
          border-right: 1px solid var(--color-border-light-primary);
        "
      >
        <h3 style="margin-top: 0;">Contents</h3>

        <button
          type="button"
          class="cc-guide-nav"
          data-target="cc-guide-quick-start"
          style="width:100%; text-align:left; margin:2px 0;"
        >
          Quick Start
        </button>

        <button
          type="button"
          class="cc-guide-nav"
          data-target="cc-guide-triggers"
          style="width:100%; text-align:left; margin:2px 0;"
        >
          Triggers
        </button>

        <button
          type="button"
          class="cc-guide-nav"
          data-target="cc-guide-stacks"
          style="width:100%; text-align:left; margin:2px 0;"
        >
          Stacks
        </button>

        <button
          type="button"
          class="cc-guide-nav"
          data-target="cc-guide-if"
          style="width:100%; text-align:left; margin:2px 0;"
        >
          If / Else
        </button>

        <button
          type="button"
          class="cc-guide-nav"
          data-target="cc-guide-saves"
          style="width:100%; text-align:left; margin:2px 0;"
        >
          Saving Throws
        </button>

        <button
          type="button"
          class="cc-guide-nav"
          data-target="cc-guide-damage"
          style="width:100%; text-align:left; margin:2px 0;"
        >
          Damage
        </button>

        <button
          type="button"
          class="cc-guide-nav"
          data-target="cc-guide-healing"
          style="width:100%; text-align:left; margin:2px 0;"
        >
          Healing
        </button>

        <button
          type="button"
          class="cc-guide-nav"
          data-target="cc-guide-temphp"
          style="width:100%; text-align:left; margin:2px 0;"
        >
          Temporary HP
        </button>

        <button
          type="button"
          class="cc-guide-nav"
          data-target="cc-guide-conditions"
          style="width:100%; text-align:left; margin:2px 0;"
        >
          Other Conditions
        </button>

        <button
          type="button"
          class="cc-guide-nav"
          data-target="cc-guide-modifiers"
          style="width:100%; text-align:left; margin:2px 0;"
        >
          AC & Save Modifiers
        </button>

        <button
          type="button"
          class="cc-guide-nav"
          data-target="cc-guide-health"
          style="width:100%; text-align:left; margin:2px 0;"
        >
          Health & Math
        </button>

        <button
          type="button"
          class="cc-guide-nav"
          data-target="cc-guide-rolls"
          style="width:100%; text-align:left; margin:2px 0;"
        >
          Rolls & Messages
        </button>

        <button
          type="button"
          class="cc-guide-nav"
          data-target="cc-guide-examples"
          style="width:100%; text-align:left; margin:2px 0;"
        >
          Common Examples
        </button>

        <button
          type="button"
          class="cc-guide-nav"
          data-target="cc-guide-troubleshooting"
          style="width:100%; text-align:left; margin:2px 0;"
        >
          Troubleshooting
        </button>
      </aside>


      <!-- ================================================== -->
      <!-- Guide                                              -->
      <!-- ================================================== -->

      <main
        class="cc-guide-content"
        style="
          overflow-y: auto;
          padding-right: 12px;
          scroll-behavior: smooth;
        "
      >

        <!-- ================================================= -->
        <!-- Quick Start                                       -->
        <!-- ================================================= -->

        <section
          id="cc-guide-quick-start"
          style="${sectionStyle}"
        >
          <h1 style="${headingStyle}">
            Custom Condition Scripting
          </h1>

          <p>
            Most condition scripts follow a simple pattern:
          </p>

          <pre>on startTurn
damage 1d6 fire</pre>

          <p>
            The first line tells the condition
            <strong>when</strong> to run.
            The following lines tell it
            <strong>what to do</strong>.
          </p>

          <div style="${noteStyle}">
            <strong>Tip:</strong>
            Commands continue to belong to the current trigger
            until another <code>on ...</code> line appears.
          </div>

          <p>
            For example, one condition can do different things
            when applied, at the start of a turn, and at the end
            of a turn:
          </p>

          <pre>on apply
set stacks 3

on startTurn
damage 1d6 fire

on endTurn
save dex 13</pre>

          <p>
            Blank lines are optional and are only there to make
            scripts easier to read.
          </p>
        </section>


        <!-- ================================================= -->
        <!-- Triggers                                          -->
        <!-- ================================================= -->

        <section
          id="cc-guide-triggers"
          style="${sectionStyle}"
        >
          <h2 style="${headingStyle}">
            Triggers
          </h2>

          <p>
            Triggers are the most important part of a script.
            Every normal command must appear underneath one.
          </p>

          <h3>on apply</h3>

          <pre>on apply
message The condition is applied.</pre>

          <p>
            Runs once when the condition is first added.
          </p>

          <p>Common uses:</p>

          <ul>
            <li>Set starting stacks.</li>
            <li>Apply an AC bonus or penalty.</li>
            <li>Modify saving throw bonuses.</li>
            <li>Grant temporary HP.</li>
            <li>Post an introductory message.</li>
          </ul>

          <pre>on apply
set stacks 3
ac -1</pre>


          <h3>on startTurn</h3>

          <pre>on startTurn
damage 1d6 fire</pre>

          <p>
            Runs whenever the affected creature begins its turn.
          </p>

          <p>Common uses:</p>

          <ul>
            <li>Ongoing damage.</li>
            <li>Regeneration.</li>
            <li>Temporary shields.</li>
            <li>Reducing duration stacks.</li>
          </ul>


          <h3>on endTurn</h3>

          <pre>on endTurn
save con 13</pre>

          <p>
            Runs whenever the affected creature ends its turn.
          </p>

          <p>
            This is especially useful for
            <strong>save ends</strong> conditions.
          </p>


          <h3>on remove</h3>

          <pre>on remove
message The effect ends.</pre>

          <p>
            Runs when the condition is removed.
          </p>

          <div style="${noteStyle}">
            You normally do <strong>not</strong> need to undo
            AC, save DC, or save bonus modifiers here.
            Those modifiers belong to the Active Effect and
            disappear when the condition is removed.
          </div>
        </section>


        <!-- ================================================= -->
        <!-- Stacks                                            -->
        <!-- ================================================= -->

        <section
          id="cc-guide-stacks"
          style="${sectionStyle}"
        >
          <h2 style="${headingStyle}">
            Stacks
          </h2>

          <p>
            Stacks give a condition a number that can increase,
            decrease, or be used by other commands.
          </p>

          <h3>Set Stacks</h3>

          <pre>set stacks 3</pre>

          <p>
            Replaces the current stack count with exactly 3.
          </p>


          <h3>Add Stacks</h3>

          <pre>add stacks 1</pre>

          <pre>add stacks 2</pre>


          <h3>Remove Stacks</h3>

          <pre>remove stacks 1</pre>

          <p>
            Stacks cannot go below zero.
          </p>


          <h3>Visible Stack Count</h3>

          <p>
            When a condition has stacks, its Active Effect name
            displays the current amount:
          </p>

          <pre>Burning [3]</pre>


          <h3>Stacks As Duration</h3>

          <p>
            A very common use is to let stacks represent how
            many rounds remain:
          </p>

          <pre>on apply
set stacks 3

on startTurn
remove stacks 1

if stacks &lt;= 0
remove self
end</pre>

          <p>
            This condition lasts for three start-of-turn triggers
            and then removes itself.
          </p>


          <h3>Stack Math</h3>

          <pre>add stacks 1 + 2</pre>

          <p>
            This adds 3 stacks.
          </p>

          <pre>set stacks missingHealth / 10</pre>

          <p>
            If the creature is missing 27 HP, this becomes
            2 stacks.
          </p>

          <div style="${noteStyle}">
            Stack counts are whole numbers.
            Decimal results are truncated toward zero.
          </div>
        </section>


        <!-- ================================================= -->
        <!-- If / Else                                         -->
        <!-- ================================================= -->

        <section
          id="cc-guide-if"
          style="${sectionStyle}"
        >
          <h2 style="${headingStyle}">
            If / Else / End
          </h2>

          <p>
            Conditions can make decisions using
            <code>if</code> statements.
          </p>

          <pre>if stacks &gt;= 3
message Three or more stacks!
end</pre>

          <p>
            Every <code>if</code> requires a matching
            <code>end</code>.
          </p>


          <h3>Else</h3>

          <pre>if stacks &gt;= 3
damage 2d6 fire
else
damage 1d6 fire
end</pre>

          <p>
            <code>else</code> is optional.
          </p>


          <h3>Supported Comparisons</h3>

          <pre>=
==
!=
&gt;
&lt;
&gt;=
&lt;=</pre>

          <p>
            Both <code>=</code> and <code>==</code>
            mean equality.
          </p>


          <h3>Check Stacks</h3>

          <pre>if stacks &gt; 0
message The effect is still active.
end</pre>


          <h3>Check Health</h3>

          <pre>if health &lt;= maxHealth / 2
message Below half health.
end</pre>


          <h3>Nested If Statements</h3>

          <pre>if hasCondition Prone

if health &lt;= maxHealth / 2
damage 2d6 bludgeoning
else
damage 1d6 bludgeoning
end

end</pre>

          <div style="${noteStyle}">
            Command order matters.
            The script always executes from top to bottom.
          </div>
        </section>


        <!-- ================================================= -->
        <!-- Saves                                             -->
        <!-- ================================================= -->

        <section
          id="cc-guide-saves"
          style="${sectionStyle}"
        >
          <h2 style="${headingStyle}">
            Automatic Saving Throws
          </h2>

          <pre>save con 13</pre>

          <p>
            Automatically makes the affected creature roll a
            Constitution saving throw against DC 13.
          </p>

          <p>Valid abilities:</p>

          <pre>str
dex
con
int
wis
cha</pre>


          <h3>Check Success</h3>

          <pre>save con 13

if saveSuccess
message The save succeeds.
end</pre>


          <h3>Check Failure</h3>

          <pre>save wis 15

if saveFailure
damage 1d6 psychic
end</pre>


          <h3>Save Ends</h3>

          <pre>on endTurn
save con 13

if saveSuccess
remove self
end</pre>

          <p>
            This is the standard pattern for an effect that allows
            a save at the end of every turn.
          </p>


          <h3>Save DC With Stacks</h3>

          <pre>save con 10 + @stack</pre>

          <p>
            With 3 stacks, the DC becomes 13.
          </p>


          <h3>Save DC With Other Math</h3>

          <pre>save wis maxHealth / 5</pre>
        </section>


        <!-- ================================================= -->
        <!-- Damage                                            -->
        <!-- ================================================= -->

        <section
          id="cc-guide-damage"
          style="${sectionStyle}"
        >
          <h2 style="${headingStyle}">
            Damage
          </h2>

          <h3>Basic Typed Damage</h3>

          <pre>damage 1d6 fire</pre>

          <pre>damage 2d8 + 3 necrotic</pre>

          <p>
            The final word is treated as the damage type.
          </p>


          <h3>Untyped Damage</h3>

          <pre>damage 1d6</pre>


          <h3>Damage Per Stack</h3>

          <pre>damage 1d6 per @stack fire</pre>

          <p>
            At 3 stacks, the engine rolls:
          </p>

          <pre>(1d6) + (1d6) + (1d6)</pre>


          <h3>More Complex Per-Stack Damage</h3>

          <pre>damage 1d6 + 2 per @stack poison</pre>

          <p>
            At 3 stacks:
          </p>

          <pre>(1d6 + 2) + (1d6 + 2) + (1d6 + 2)</pre>

          <div style="${noteStyle}">
            For stack-based roll scaling, use
            <code>per @stack</code> rather than putting
            <code>@stack</code> directly inside the dice formula.
          </div>
        </section>


        <!-- ================================================= -->
        <!-- Healing                                           -->
        <!-- ================================================= -->

        <section
          id="cc-guide-healing"
          style="${sectionStyle}"
        >
          <h2 style="${headingStyle}">
            Healing
          </h2>

          <pre>heal 1d8</pre>

          <p>
            Restores normal hit points.
          </p>


          <h3>Healing Per Stack</h3>

          <pre>heal 1d4 per @stack</pre>


          <h3>Only Heal If Wounded</h3>

          <pre>on startTurn

if health &lt; maxHealth
heal 1d6
end</pre>
        </section>


        <!-- ================================================= -->
        <!-- Temp HP                                           -->
        <!-- ================================================= -->

        <section
          id="cc-guide-temphp"
          style="${sectionStyle}"
        >
          <h2 style="${headingStyle}">
            Temporary Hit Points
          </h2>

          <pre>temphp 1d6 + 3</pre>

          <p>
            Grants temporary hit points.
          </p>

          <p>
            Temporary HP does not stack with existing temporary HP.
            The creature keeps whichever value is larger.
          </p>


          <h3>Temporary HP Per Stack</h3>

          <pre>temphp 1d4 per @stack</pre>


          <h3>Emergency Shield</h3>

          <pre>on startTurn

if health &lt;= maxHealth / 3
temphp 2d6
end</pre>
        </section>


        <!-- ================================================= -->
        <!-- Conditions                                        -->
        <!-- ================================================= -->

        <section
          id="cc-guide-conditions"
          style="${sectionStyle}"
        >
          <h2 style="${headingStyle}">
            Apply & Check Other Conditions
          </h2>

          <h3>Apply Another Condition</h3>

          <pre>apply Poisoned</pre>

          <p>
            The engine first checks your Custom Conditions.
            If none matches, it checks Foundry's registered
            status conditions.
          </p>

          <p>
            This allows ordinary D&D conditions such as:
          </p>

          <pre>apply Stunned</pre>

          <pre>apply Prone</pre>

          <pre>apply Restrained</pre>

          <p>
            Matching is case-insensitive.
          </p>

          <p>
            If the target already has that condition, it is not
            duplicated or toggled off.
          </p>


          <h3>Check For A Condition</h3>

          <pre>if hasCondition Stunned
message The creature is stunned.
end</pre>

          <p>
            This works with both your custom conditions and
            registered Foundry conditions.
          </p>


          <h3>Check That A Condition Is Missing</h3>

          <pre>if not hasCondition Prone
message The creature is still standing.
end</pre>


          <h3>Condition Interaction</h3>

          <pre>if hasCondition Wet
damage 2d6 lightning
else
damage 1d6 lightning
end</pre>

          <div style="${noteStyle}">
            Conditions added by other modules may also work if
            that module registers them as Foundry status effects.
          </div>
        </section>


        <!-- ================================================= -->
        <!-- Modifiers                                         -->
        <!-- ================================================= -->

        <section
          id="cc-guide-modifiers"
          style="${sectionStyle}"
        >
          <h2 style="${headingStyle}">
            AC & Saving Throw Modifiers
          </h2>

          <h3>Armor Class</h3>

          <pre>ac +2</pre>

          <pre>ac -1</pre>

          <p>
            The modifier lasts as long as the condition exists.
          </p>


          <h3>AC Per Stack</h3>

          <pre>ac +@stack</pre>

          <p>
            3 stacks means +3 AC.
          </p>

          <pre>ac -@stack</pre>

          <p>
            3 stacks means -3 AC.
          </p>


          <h3>Multiply A Stack Modifier</h3>

          <pre>ac +2 * @stack</pre>

          <p>
            3 stacks means +6 AC.
          </p>


          <h3>Spell Save DC</h3>

          <pre>saveDC +1</pre>

          <pre>saveDC -2</pre>

          <pre>saveDC +@stack</pre>


          <h3>Specific Saving Throw Bonus</h3>

          <pre>saveBonus con -2</pre>

          <p>
            Applies -2 only to Constitution saving throws.
          </p>

          <pre>saveBonus wis +1</pre>


          <h3>Saving Throw Penalty Per Stack</h3>

          <pre>saveBonus con -@stack</pre>

          <p>
            At 3 stacks, Constitution saves receive -3.
          </p>


          <h3>Modify Several Saves</h3>

          <pre>on apply
saveBonus str -2
saveBonus dex -2
saveBonus con -1</pre>

          <div style="${noteStyle}">
            AC, spell save DC, and specific saving throw modifiers
            automatically disappear when the condition is removed.
          </div>
        </section>


        <!-- ================================================= -->
        <!-- Health and Math                                    -->
        <!-- ================================================= -->

        <section
          id="cc-guide-health"
          style="${sectionStyle}"
        >
          <h2 style="${headingStyle}">
            Health & Math
          </h2>

          <p>
            Several numeric values are available inside equations:
          </p>

          <pre>health
maxHealth
tempHP
missingHealth
@stack</pre>


          <h3>health</h3>

          <p>
            The creature's current normal HP.
          </p>

          <pre>if health = 20
message Exactly 20 HP.
end</pre>


          <h3>maxHealth</h3>

          <p>
            The creature's maximum HP.
          </p>

          <pre>if health &lt;= maxHealth / 2
message Below half health.
end</pre>


          <h3>tempHP</h3>

          <p>
            The creature's current temporary hit points.
          </p>

          <pre>if tempHP &gt; 0
message A temporary shield remains.
end</pre>


          <h3>missingHealth</h3>

          <p>
            Automatically equals:
          </p>

          <pre>maxHealth - health</pre>

          <pre>if missingHealth &gt;= 20
heal 2d8
end</pre>


          <h3>Supported Math</h3>

          <pre>+
-
*
/
( )</pre>


          <h3>Examples</h3>

          <pre>set stacks maxHealth / 20</pre>

          <pre>add stacks missingHealth / 10</pre>

          <pre>if health &lt;= (maxHealth / 2) + 5
message The creature is badly hurt.
end</pre>

          <div style="${noteStyle}">
            Health values are evaluated when the command runs.
            Persistent modifiers such as AC and save bonuses use
            <code>@stack</code>, but do not currently recalculate
            automatically from changing HP.
          </div>
        </section>


        <!-- ================================================= -->
        <!-- Rolls and Messages                                 -->
        <!-- ================================================= -->

        <section
          id="cc-guide-rolls"
          style="${sectionStyle}"
        >
          <h2 style="${headingStyle}">
            Rolls, Messages & Comments
          </h2>

          <h3>Automatic Roll</h3>

          <pre>roll 1d20 + 5</pre>

          <p>
            Rolls the expression automatically and posts the result
            to chat.
          </p>

          <pre>roll 1d100</pre>


          <h3>Roll Per Stack</h3>

          <pre>roll 1d6 per @stack</pre>


          <h3>Message</h3>

          <pre>message The flames burn!</pre>

          <p>
            Sends text to chat.
          </p>

          <p>
            Messages are also useful for debugging:
          </p>

          <pre>on startTurn
message Start-turn trigger fired.
damage 1d6 fire</pre>


          <h3>Comments</h3>

          <pre>// This is a comment</pre>

          <pre># This is also a comment</pre>

          <p>
            Comments and blank lines are ignored.
          </p>
        </section>


        <!-- ================================================= -->
        <!-- Common Examples                                    -->
        <!-- ================================================= -->

        <section
          id="cc-guide-examples"
          style="${sectionStyle}"
        >
          <h2 style="${headingStyle}">
            Common Examples
          </h2>

          <p>
            These examples are intended as practical starting points
            that players can copy and adjust.
          </p>


          <h3>Burning — 3 Rounds</h3>

          <pre>on apply
set stacks 3

on startTurn
damage 1d6 fire
remove stacks 1

if stacks &lt;= 0
message The flames go out.
remove self
end</pre>

          <p>
            Stacks represent the number of rounds remaining.
            The target takes 1d6 fire damage at the start of each
            turn, loses one stack, and the condition removes itself
            after the third trigger.
          </p>


          <h3>Poison — Save Ends</h3>

          <pre>on startTurn
damage 1d6 poison

on endTurn
save con 13

if saveSuccess
remove self
end</pre>

          <p>
            The creature takes poison damage each turn and may end
            the condition with a Constitution save.
          </p>


          <h3>Bleeding — Fades Over Time</h3>

          <pre>on apply
set stacks 3

on startTurn
damage 1d4 per @stack slashing
remove stacks 1

if stacks &lt;= 0
remove self
end</pre>

          <p>
            A simple timed bleed effect.
          </p>


          <h3>Regeneration</h3>

          <pre>on startTurn

if health &lt; maxHealth
heal 1d6
end</pre>

          <p>
            The creature heals at the start of each turn,
            but only if it is missing HP.
          </p>


          <h3>Shielded</h3>

          <pre>on apply
ac +2
temphp 1d6 + 3</pre>

          <p>
            Grants +2 AC while the condition remains and gives
            temporary HP when first applied.
          </p>


          <h3>Weakening Curse</h3>

          <pre>on apply
saveBonus con -2
saveBonus wis -2</pre>

          <p>
            Applies a persistent penalty to two specific saving
            throws.
          </p>


          <h3>Stacking Weakness</h3>

          <pre>on apply
set stacks 1
saveBonus con -@stack

on startTurn
add stacks 1</pre>

          <p>
            The Constitution saving throw penalty becomes worse
            each round.
          </p>


          <h3>Stun When A Save Fails</h3>

          <pre>on endTurn
save wis 14

if saveFailure
apply Stunned
end</pre>

          <p>
            Demonstrates applying a normal D&D5e condition from
            a custom condition script.
          </p>


          <h3>Extra Damage Against Prone Targets</h3>

          <pre>on startTurn

if hasCondition Prone
damage 1d6 bludgeoning
end</pre>

          <p>
            Demonstrates checking a normal Foundry condition.
          </p>


          <h3>Low-Health Effect</h3>

          <pre>on startTurn

if health &lt;= maxHealth / 3
temphp 1d6
end</pre>

          <p>
            Grants a small emergency buffer whenever the creature
            begins its turn at one-third HP or lower.
          </p>
        </section>


        <!-- ================================================= -->
        <!-- Troubleshooting                                    -->
        <!-- ================================================= -->

        <section
          id="cc-guide-troubleshooting"
          style="${sectionStyle}"
        >
          <h2 style="${headingStyle}">
            Troubleshooting
          </h2>

          <ul>
            <li>
              Press <strong>Validate</strong> before saving a
              complicated script.
            </li>

            <li>
              Every normal command needs to appear underneath an
              <code>on ...</code> trigger.
            </li>

            <li>
              Every <code>if</code> requires a matching
              <code>end</code>.
            </li>

            <li>
              Use <code>message</code> while debugging to confirm
              that a trigger actually ran.
            </li>

            <li>
              Remember that commands execute from top to bottom.
            </li>

            <li>
              <code>damage X per @stack</code> repeats X once for
              every current stack.
            </li>

            <li>
              AC, save DC, and save bonus modifiers may use
              <code>@stack</code>.
            </li>

            <li>
              Health equations may use
              <code>health</code>,
              <code>maxHealth</code>,
              <code>tempHP</code>, and
              <code>missingHealth</code>.
            </li>

            <li>
              Stack math produces whole numbers.
              Decimal results are truncated toward zero.
            </li>

            <li>
              <code>apply</code> and
              <code>hasCondition</code> search both custom
              conditions and registered Foundry status conditions.
            </li>
          </ul>


          <h3>Debugging A Trigger</h3>

          <p>
            If you are unsure whether a trigger is firing, temporarily
            add a message:
          </p>

          <pre>on startTurn
message Start turn worked.
damage 1d6 fire</pre>

          <p>
            If the message appears but the damage does not, then the
            trigger is working and the problem is specifically with
            the damage command.
          </p>


          <h3>Command Order Example</h3>

          <pre>damage 1d6 per @stack fire
remove stacks 1</pre>

          <p>
            Damage uses the current stack count and then removes
            a stack.
          </p>

          <pre>remove stacks 1
damage 1d6 per @stack fire</pre>

          <p>
            This removes the stack first, so the damage uses the
            lower stack count.
          </p>
        </section>

      </main>
    </div>
  `;

  new Dialog(
    {
      title: "Custom Condition Scripting Guide",
      content,

      buttons: {
        close: {
          icon: '<i class="fas fa-times"></i>',
          label: "Close"
        }
      },

      default: "close",

      render: (html) => {
        html.find(".cc-guide-nav").on("click", (event) => {
          event.preventDefault();

          const targetId =
            event.currentTarget.dataset.target;

          if (!targetId) return;

          const root =
            html instanceof jQuery
              ? html[0]
              : html;

          const target =
            root?.querySelector(
              `#${targetId}`
            );

          if (!target) return;

          target.scrollIntoView({
            behavior: "smooth",
            block: "start"
          });
        });
      }
    },
    {
      width: 900,
      height: 780,
      resizable: true
    }
  ).render(true);
}