import {
  buildStartTurnDamageScript,
  validateConditionScript,
  executeConditionScript,
  openScriptHelp
} from "./scripting.js";

const MODULE_ID = "custom-conditions";
const SOCKET_NAME = `module.${MODULE_ID}`;


/* ============================================================ */
/* Initialization                                               */
/* ============================================================ */

Hooks.once("init", () => {
  console.log(`${MODULE_ID} | Initializing`);

  game.settings.register(MODULE_ID, "conditions", {
    name: "Custom Conditions",
    scope: "world",
    config: false,
    type: Array,
    default: [],

    onChange: () => {
      try {
        registerCustomStatusEffects();
      } catch (err) {
        console.error(
          `${MODULE_ID} | Failed to refresh status effects`,
          err
        );
      }
    }
  });
});


Hooks.once("ready", () => {
  try {
    registerCustomStatusEffects();
    setupSocket();
    exposeApi();
  } catch (err) {
    console.error(
      `${MODULE_ID} | Ready setup failed`,
      err
    );
  }

  console.log(`${MODULE_ID} | Ready`);
});


/* ============================================================ */
/* Condition storage                                            */
/* ============================================================ */

function getConditions() {
  try {
    return foundry.utils.deepClone(
      game.settings.get(
        MODULE_ID,
        "conditions"
      ) ?? []
    );
  } catch {
    return [];
  }
}


async function saveConditions(conditions) {
  if (!game.user?.isGM) {
    throw new Error(
      "Only a GM can directly save world conditions."
    );
  }

  await game.settings.set(
    MODULE_ID,
    "conditions",
    conditions
  );

  registerCustomStatusEffects();
}


function makeId(name) {
  const base =
    String(name)
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "") ||
    "condition";

  return (
    `${MODULE_ID}-` +
    `${base}-` +
    `${Date.now().toString(36)}`
  );
}


function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}


/* ============================================================ */
/* Register Foundry status effects                              */
/* ============================================================ */

function registerCustomStatusEffects() {
  if (!CONFIG.statusEffects) {
    return;
  }

  CONFIG.statusEffects =
    CONFIG.statusEffects.filter(
      (status) =>
        !String(
          status.id ?? ""
        ).startsWith(
          `${MODULE_ID}-`
        )
    );

  for (
    const condition of
      getConditions()
  ) {
    CONFIG.statusEffects.push({
      id: condition.id,

      name: condition.name,

      img:
        condition.icon ||
        "icons/svg/aura.svg",

      description:
        condition.script ||
        ""
    });
  }
}


/* ============================================================ */
/* Active Effect helpers                                        */
/* ============================================================ */

function effectConditionIds(effect) {
  const ids = new Set();

  const flagId =
    effect?.getFlag?.(
      MODULE_ID,
      "conditionId"
    );

  if (flagId) {
    ids.add(
      String(flagId)
    );
  }

  for (
    const status of
      effect?.statuses ?? []
  ) {
    ids.add(
      String(status)
    );
  }

  return ids;
}


function resolveConditionForEffect(
  effect,
  conditions = getConditions()
) {
  const ids =
    effectConditionIds(effect);

  return (
    conditions.find(
      (condition) =>
        ids.has(condition.id)
    ) ??
    null
  );
}


function findConditionEffect(
  actor,
  conditionId
) {
  return (
    Array.from(
      actor?.effects ?? []
    ).find(
      (effect) =>
        effectConditionIds(
          effect
        ).has(
          conditionId
        )
    ) ??
    null
  );
}


function getConditionStacksOnActor(
  actor,
  conditionId
) {
  const effect =
    findConditionEffect(
      actor,
      conditionId
    );

  if (!effect) {
    return null;
  }

  return Math.max(
    0,
    Number(
      effect.getFlag(
        MODULE_ID,
        "stacks"
      ) ?? 0
    )
  );
}


/* ============================================================ */
/* Create condition ActiveEffect                                */
/* ============================================================ */

async function createConditionEffect(
  actor,
  condition
) {
  if (!actor) {
    return null;
  }

  /*
   * Applying from a script should not toggle
   * an existing condition off.
   */
  const existing =
    findConditionEffect(
      actor,
      condition.id
    );

  if (existing) {
    return existing;
  }

  const created =
    await actor.createEmbeddedDocuments(
      "ActiveEffect",
      [
        {
          name:
            condition.name,

          img:
            condition.icon ||
            "icons/svg/aura.svg",

          statuses: [
            condition.id
          ],

          description:
            condition.script ||
            "",

          flags: {
            [MODULE_ID]: {
              conditionId:
                condition.id,

              script:
                condition.script ||
                "",

              stacks:
                0,

              baseName:
                condition.name,

              journalUuid:
                condition.journalUuid ||
                null
            }
          }
        }
      ]
    );

  return (
    created[0] ??
    null
  );
}


/* ============================================================ */
/* Script execution wrapper                                     */
/* ============================================================ */

async function runConditionScript({
  actor,
  token = null,
  effect,
  condition,
  trigger
}) {
  try {
    await executeConditionScript({
      moduleId:
        MODULE_ID,

      actor,
      token,
      effect,
      condition,
      trigger,

      getConditions,

      applyCondition:
        createConditionEffect
    });
  } catch (err) {
    console.error(
      `${MODULE_ID} | Script execution failed`,
      {
        actor,
        token,
        effect,
        condition,
        trigger,
        err
      }
    );

    ui.notifications.error(
      `${condition?.name ?? "Condition"}: ${err.message}`
    );
  }
}


/* ============================================================ */
/* Active GM helper                                             */
/* ============================================================ */

function isActiveGM() {
  if (
    typeof game.user
      ?.isActiveGM ===
    "boolean"
  ) {
    return game.user.isActiveGM;
  }

  const activeGM =
    game.users?.activeGM;

  if (activeGM) {
    return (
      activeGM.id ===
      game.user?.id
    );
  }

  return Boolean(
    game.user?.isGM
  );
}


/* ============================================================ */
/* Player -> GM socket                                          */
/* ============================================================ */

const pendingRequests =
  new Map();


function setupSocket() {
  if (!game.socket) {
    return;
  }

  game.socket.on(
    SOCKET_NAME,
    async (data) => {
      if (
        !data ||
        typeof data !== "object"
      ) {
        return;
      }

      /*
       * Response to a request we made.
       */
      if (
        data.type ===
        "response"
      ) {
        if (
          data.targetUserId !==
          game.user?.id
        ) {
          return;
        }

        const pending =
          pendingRequests.get(
            data.requestId
          );

        if (!pending) {
          return;
        }

        clearTimeout(
          pending.timeout
        );

        pendingRequests.delete(
          data.requestId
        );

        if (data.ok) {
          pending.resolve(
            data.result
          );
        } else {
          pending.reject(
            new Error(
              data.message ||
              "GM request failed."
            )
          );
        }

        return;
      }

      /*
       * Only the active GM handles
       * modification requests.
       */
      if (!isActiveGM()) {
        return;
      }

      try {
        const result =
          await handleGMRequest(
            data
          );

        game.socket.emit(
          SOCKET_NAME,
          {
            type:
              "response",

            requestId:
              data.requestId,

            targetUserId:
              data.userId,

            ok:
              true,

            result
          }
        );
      } catch (err) {
        console.error(
          `${MODULE_ID} | Socket request failed`,
          err
        );

        game.socket.emit(
          SOCKET_NAME,
          {
            type:
              "response",

            requestId:
              data.requestId,

            targetUserId:
              data.userId,

            ok:
              false,

            message:
              err.message ||
              "Request failed."
          }
        );
      }
    }
  );
}


function requestGM(
  type,
  payload = {}
) {
  /*
   * A GM can simply perform the
   * request directly.
   */
  if (game.user?.isGM) {
    return handleGMRequest({
      type,
      payload,

      userId:
        game.user.id
    });
  }

  if (
    !game.users?.activeGM
  ) {
    return Promise.reject(
      new Error(
        "No active GM is connected."
      )
    );
  }

  if (!game.socket) {
    return Promise.reject(
      new Error(
        "The Foundry module socket is unavailable."
      )
    );
  }

  const requestId =
    foundry.utils.randomID?.() ??
    `${Date.now()}-${Math.random()}`;

  return new Promise(
    (resolve, reject) => {
      const timeout =
        setTimeout(
          () => {
            pendingRequests.delete(
              requestId
            );

            reject(
              new Error(
                "The GM did not answer. " +
                'Make sure module.json contains "socket": true.'
              )
            );
          },
          8000
        );

      pendingRequests.set(
        requestId,
        {
          resolve,
          reject,
          timeout
        }
      );

      game.socket.emit(
        SOCKET_NAME,
        {
          type,
          payload,
          requestId,

          userId:
            game.user.id
        }
      );
    }
  );
}


/* ============================================================ */
/* GM modification requests                                     */
/* ============================================================ */

async function handleGMRequest(
  request
) {
  const payload =
    request.payload ?? {};

  /* ---------------------------------------------------------- */
  /* CREATE                                                     */
  /* ---------------------------------------------------------- */

  if (
    request.type ===
    "createCondition"
  ) {
    const name =
      String(
        payload.name ?? ""
      ).trim();

    const icon =
      String(
        payload.icon ??
        "icons/svg/aura.svg"
      ).trim();

    const script =
      String(
        payload.script ?? ""
      );

    let journalUuid =
      String(
        payload.journalUuid ??
        ""
      ).trim();

    if (!name) {
      throw new Error(
        "Condition name is required."
      );
    }

    const validation =
      validateConditionScript(
        script
      );

    if (!validation.ok) {
      throw new Error(
        validation.errors[0]
      );
    }

    if (
      payload.autoPage &&
      !journalUuid
    ) {
      const page =
        await createJournalPageForCondition(
          name,
          script
        );

      journalUuid =
        page.uuid;
    }

    const condition = {
      id:
        makeId(name),

      name,
      icon,
      script,

      journalUuid:
        journalUuid ||
        null,

      authorUserId:
        request.userId ||
        null
    };

    const list =
      getConditions();

    list.push(
      condition
    );

    await saveConditions(
      list
    );

    return condition;
  }

  /* ---------------------------------------------------------- */
  /* UPDATE                                                     */
  /* ---------------------------------------------------------- */

  if (
    request.type ===
    "updateCondition"
  ) {
    const id =
      String(
        payload.id ?? ""
      );

    const list =
      getConditions();

    const index =
      list.findIndex(
        (entry) =>
          entry.id === id
      );

    if (
      index === -1
    ) {
      throw new Error(
        "Condition not found."
      );
    }

    const existing =
      list[index];

    const user =
      game.users?.get?.(
        request.userId
      );

    /*
     * GM can edit anything.
     * Players can edit their own.
     */
    if (
      !user?.isGM &&
      existing.authorUserId &&
      existing.authorUserId !==
        user?.id
    ) {
      throw new Error(
        "You can only edit conditions you created."
      );
    }

    const name =
      String(
        payload.name ?? ""
      ).trim();

    const icon =
      String(
        payload.icon ??
        "icons/svg/aura.svg"
      ).trim();

    const script =
      String(
        payload.script ??
        ""
      );

    let journalUuid =
      String(
        payload.journalUuid ??
        ""
      ).trim();

    if (!name) {
      throw new Error(
        "Condition name is required."
      );
    }

    const validation =
      validateConditionScript(
        script
      );

    if (
      !validation.ok
    ) {
      throw new Error(
        validation.errors[0]
      );
    }

    if (
      payload.autoPage &&
      !journalUuid
    ) {
      const page =
        await createJournalPageForCondition(
          name,
          script
        );

      journalUuid =
        page.uuid;
    }

    const updated = {
      ...existing,

      name,
      icon,
      script,

      journalUuid:
        journalUuid ||
        null
    };

    list[index] =
      updated;

    await saveConditions(
      list
    );

    await syncExistingConditionEffects(
      updated
    );

    if (
      updated.journalUuid
    ) {
      await updateConditionJournalPage(
        updated
      );
    }

    return updated;
  }

  /* ---------------------------------------------------------- */
  /* DELETE                                                     */
  /* ---------------------------------------------------------- */

  if (
    request.type ===
    "deleteCondition"
  ) {
    const id =
      String(
        payload.id ?? ""
      );

    const user =
      game.users?.get?.(
        request.userId
      );

    const list =
      getConditions();

    const condition =
      list.find(
        (entry) =>
          entry.id === id
      );

    if (!condition) {
      throw new Error(
        "Condition not found."
      );
    }

    if (
      !user?.isGM &&
      condition.authorUserId &&
      condition.authorUserId !==
        user?.id
    ) {
      throw new Error(
        "You can only delete conditions you created."
      );
    }

    await saveConditions(
      list.filter(
        (entry) =>
          entry.id !== id
      )
    );

    return true;
  }

  throw new Error(
    `Unknown request: ${request.type}`
  );
}


/* ============================================================ */
/* Synchronize edited conditions                                */
/* ============================================================ */

async function syncExistingConditionEffects(
  condition
) {
  const actors =
    new Set();

  /*
   * World actors.
   */
  for (
    const actor of
      game.actors?.contents ??
      []
  ) {
    actors.add(
      actor
    );
  }

  /*
   * Synthetic token actors on
   * the current canvas.
   */
  for (
    const token of
      canvas?.tokens?.placeables ??
      []
  ) {
    if (
      token.actor
    ) {
      actors.add(
        token.actor
      );
    }
  }

  for (
    const actor of
      actors
  ) {
    const effects =
      Array.from(
        actor.effects ??
        []
      );

    for (
      const effect of effects
    ) {
      if (
        !effectConditionIds(
          effect
        ).has(
          condition.id
        )
      ) {
        continue;
      }

      const stacks =
        Math.max(
          0,
          Number(
            effect.getFlag(
              MODULE_ID,
              "stacks"
            ) ?? 0
          )
        );

      const displayedName =
        stacks > 0
          ? (
            `${condition.name} ` +
            `[${stacks}]`
          )
          : condition.name;

      await effect.update({
        name:
          displayedName,

        img:
          condition.icon ||
          "icons/svg/aura.svg",

        description:
          condition.script ||
          "",

        [`flags.${MODULE_ID}.conditionId`]:
          condition.id,

        [`flags.${MODULE_ID}.script`]:
          condition.script ||
          "",

        [`flags.${MODULE_ID}.baseName`]:
          condition.name,

        [`flags.${MODULE_ID}.journalUuid`]:
          condition.journalUuid ||
          null
      });

      /*
       * Re-run persistent modifier setup
       * so changes to things like ac +@stack
       * are reflected immediately.
       *
       * Only the "apply" section is appropriate
       * here because AC/saveDC modifiers normally
       * belong there.
       */
      await runConditionScript({
        actor,

        effect,

        condition,

        trigger:
          "apply"
      });
    }
  }
}


/* ============================================================ */
/* Journal                                                      */
/* ============================================================ */

async function ensureConditionsJournal() {
  const existing =
    game.journal.find(
      (journal) =>
        journal.getFlag(
          MODULE_ID,
          "isConditionsJournal"
        )
    );

  if (existing) {
    return existing;
  }

  const journal =
    await JournalEntry.create({
      name:
        "Custom Conditions",

      ownership: {
        default:
          CONST
            .DOCUMENT_OWNERSHIP_LEVELS
            .OBSERVER
      }
    });

  await journal.setFlag(
    MODULE_ID,
    "isConditionsJournal",
    true
  );

  return journal;
}


function buildJournalContent(
  name,
  script
) {
  return `
    <div
      style="
        background:#f5f1e8;
        color:#202020;
        padding:14px;
        border:1px solid #8c8679;
        border-radius:6px;
      "
    >
      <h2
        style="
          color:#202020;
          margin-top:0;
        "
      >
        ${escapeHtml(name)}
      </h2>

      ${
        script
          ? `
            <pre
              style="
                background:#fffdf8;
                color:#202020;
                border:1px solid #c5beb0;
                border-radius:4px;
                padding:10px;
                white-space:pre-wrap;
              "
            >${escapeHtml(script)}</pre>
          `
          : `
            <p>
              <em>
                Describe what
                <strong>${escapeHtml(name)}</strong>
                does.
              </em>
            </p>
          `
      }
    </div>
  `;
}


async function createJournalPageForCondition(
  name,
  script
) {
  const journal =
    await ensureConditionsJournal();

  const pages =
    await journal.createEmbeddedDocuments(
      "JournalEntryPage",
      [
        {
          name,

          type:
            "text",

          text: {
            content:
              buildJournalContent(
                name,
                script
              ),

            format:
              1
          }
        }
      ]
    );

  return pages[0];
}


async function updateConditionJournalPage(
  condition
) {
  if (
    !condition.journalUuid
  ) {
    return;
  }

  try {
    const page =
      await fromUuid(
        condition.journalUuid
      );

    if (
      !page ||
      page.documentName !==
        "JournalEntryPage"
    ) {
      return;
    }

    await page.update({
      name:
        condition.name,

      "text.content":
        buildJournalContent(
          condition.name,
          condition.script ||
          ""
        )
    });
  } catch (err) {
    console.warn(
      `${MODULE_ID} | Could not update journal page`,
      err
    );
  }
}


function journalPageOptionsHtml(
  selectedUuid = ""
) {
  const options = [
    '<option value="">— None —</option>'
  ];

  for (
    const journal of
      game.journal.contents
  ) {
    for (
      const page of
        journal.pages.contents
    ) {
      const selected =
        page.uuid ===
        selectedUuid
          ? " selected"
          : "";

      const label =
        `${journal.name}: ${page.name}`;

      options.push(
        `<option value="${escapeHtml(
          page.uuid
        )}"${selected}>` +
        `${escapeHtml(label)}` +
        `</option>`
      );
    }
  }

  return options.join("");
}


async function openLinkedJournal(
  uuid
) {
  if (!uuid) {
    ui.notifications.warn(
      "No journal page linked."
    );

    return;
  }

  const document =
    await fromUuid(
      uuid
    );

  if (!document) {
    ui.notifications.warn(
      "Linked journal page not found."
    );

    return;
  }

  if (
    document.documentName ===
    "JournalEntryPage"
  ) {
    document.parent
      ?.sheet
      ?.render(
        true,
        {
          pageId:
            document.id
        }
      );
  } else {
    document.sheet
      ?.render(
        true
      );
  }
}


/* ============================================================ */
/* Damage type dropdown                                         */
/* ============================================================ */

function damageTypeOptionsHtml(
  selected = "fire"
) {
  const configured =
    CONFIG.DND5E
      ?.damageTypes ??
    {};

  const fallback = {
    acid: "Acid",
    bludgeoning: "Bludgeoning",
    cold: "Cold",
    fire: "Fire",
    force: "Force",
    lightning: "Lightning",
    necrotic: "Necrotic",
    piercing: "Piercing",
    poison: "Poison",
    psychic: "Psychic",
    radiant: "Radiant",
    slashing: "Slashing",
    thunder: "Thunder"
  };

  const damageTypes =
    Object.keys(
      configured
    ).length
      ? configured
      : fallback;

  return Object.entries(
    damageTypes
  )
    .map(
      ([key, data]) => {
        let label =
          typeof data ===
          "string"
            ? data
            : (
              data?.label ??
              key
            );

        try {
          label =
            game.i18n.localize(
              label
            );
        } catch {
          // Keep raw label.
        }

        return (
          `<option value="${escapeHtml(
            key
          )}"` +
          (
            key === selected
              ? " selected"
              : ""
          ) +
          `>${escapeHtml(label)}</option>`
        );
      }
    )
    .join("");
}


/* ============================================================ */
/* Scene controls                                               */
/* ============================================================ */

Hooks.on(
  "getSceneControlButtons",
  (controls) => {
    const openManager =
      () =>
        openConditionManager();

    /*
     * Foundry v13.
     */
    if (
      controls?.tokens?.tools
    ) {
      controls
        .tokens
        .tools
        ["custom-conditions"] =
        {
          name:
            "custom-conditions",

          title:
            "Custom Conditions",

          icon:
            "fas fa-flask",

          button:
            true,

          order:
            Object.keys(
              controls.tokens.tools
            ).length,

          onChange:
            openManager
        };

      return;
    }

    /*
     * Older fallback.
     */
    if (
      Array.isArray(
        controls
      )
    ) {
      const tokenControls =
        controls.find(
          (control) =>
            control.name ===
              "token" ||
            control.name ===
              "tokens"
        );

      if (!tokenControls) {
        return;
      }

      if (
        Array.isArray(
          tokenControls.tools
        )
      ) {
        tokenControls.tools.push({
          name:
            "custom-conditions",

          title:
            "Custom Conditions",

          icon:
            "fas fa-flask",

          button:
            true,

          onClick:
            openManager
        });
      }
    }
  }
);


/* ============================================================ */
/* Token HUD                                                    */
/* ============================================================ */

Hooks.on(
  "renderTokenHUD",
  (
    app,
    html
  ) => {
    const root =
      html instanceof jQuery
        ? html[0]
        : html;

    if (
      !root ||
      root.querySelector(
        ".custom-conditions-hud-btn"
      )
    ) {
      return;
    }

    const button =
      document.createElement(
        "button"
      );

    button.type =
      "button";

    button.classList.add(
      "control-icon",
      "custom-conditions-hud-btn"
    );

    button.title =
      "Apply Custom Condition";

    button.innerHTML =
      '<i class="fas fa-flask"></i>';

    button.addEventListener(
      "click",
      (event) => {
        event.preventDefault();
        event.stopPropagation();

        const token =
          app.object;

        if (!token?.actor) {
          return;
        }

        openApplyConditionDialog(
          token
        );
      }
    );

    const right =
      root.querySelector(
        ".col.right"
      ) ??
      root.querySelector(
        ".right"
      );

    const combat =
      root.querySelector(
        '[data-action="combat"]'
      ) ??
      root.querySelector(
        ".combat"
      );

    if (
      combat?.parentElement
    ) {
      combat.parentElement.insertBefore(
        button,
        combat.nextSibling
      );
    } else if (right) {
      right.appendChild(
        button
      );
    } else {
      root.appendChild(
        button
      );
    }
  }
);


/* ============================================================ */
/* Condition manager                                            */
/* ============================================================ */

function openConditionManager() {
  const conditions =
    getConditions();

  const listHtml =
    conditions.length
      ? conditions
          .map(
            (condition) => {
              const journalButton =
                condition.journalUuid
                  ? `
                    <button
                      type="button"
                      class="cc-open-journal"
                      data-uuid="${escapeHtml(
                        condition.journalUuid
                      )}"
                      title="Open journal"
                    >
                      <i class="fas fa-book"></i>
                    </button>
                  `
                  : "";

              return `
                <div
                  class="cc-condition-row"
                  style="
                    display:flex;
                    align-items:center;
                    gap:8px;
                    margin:5px 0;
                  "
                >
                  <img
                    src="${escapeHtml(
                      condition.icon ||
                      "icons/svg/aura.svg"
                    )}"
                    width="28"
                    height="28"
                  />

                  <span
                    style="
                      flex:1;
                      font-weight:600;
                    "
                  >
                    ${escapeHtml(
                      condition.name
                    )}
                  </span>

                  ${journalButton}

                  <button
                    type="button"
                    class="cc-edit"
                    data-id="${escapeHtml(
                      condition.id
                    )}"
                    title="Edit"
                  >
                    <i class="fas fa-pen"></i>
                  </button>

                  <button
                    type="button"
                    class="cc-delete"
                    data-id="${escapeHtml(
                      condition.id
                    )}"
                    title="Delete"
                  >
                    <i class="fas fa-trash"></i>
                  </button>
                </div>
              `;
            }
          )
          .join("")
      : (
        `<p class="notes">` +
        `No custom conditions yet.` +
        `</p>`
      );

  const dialog =
    new Dialog(
      {
        title:
          "Custom Conditions",

        content: `
          <div class="cc-manager">

            <h3>Existing Conditions</h3>

            <div>
              ${listHtml}
            </div>

            <hr/>

            <h3>Create Condition</h3>

            <div class="form-group">
              <label>Name</label>

              <input
                id="cc-name"
                type="text"
                placeholder="Burning"
              />
            </div>

            <div class="form-group">
              <label>Icon</label>

              <div
                style="
                  display:flex;
                  gap:6px;
                "
              >
                <input
                  id="cc-icon"
                  type="text"
                  value="icons/svg/aura.svg"
                  style="flex:1;"
                />

                <button
                  id="cc-pick-icon"
                  type="button"
                >
                  <i class="fas fa-image"></i>
                </button>
              </div>
            </div>

            <div class="form-group">
              <label>Template</label>

              <select id="cc-template">
                <option value="custom">
                  Custom
                </option>

                <option value="start-turn-damage">
                  Damage at start of turn
                </option>
              </select>
            </div>

            <div
              id="cc-damage-template"
              style="
                display:none;
                border-left:3px solid var(--color-border-highlight);
                padding-left:10px;
                margin:8px 0;
              "
            >

              <div class="form-group">
                <label>Damage</label>

                <div
                  style="
                    display:flex;
                    align-items:center;
                    gap:6px;
                  "
                >

                  <input
                    id="cc-dice-count"
                    type="number"
                    min="1"
                    value="1"
                    style="width:70px;"
                  />

                  <span>d</span>

                  <select
                    id="cc-die-size"
                    style="width:90px;"
                  >
                    <option value="4">4</option>
                    <option value="6" selected>6</option>
                    <option value="8">8</option>
                    <option value="10">10</option>
                    <option value="12">12</option>
                    <option value="20">20</option>
                  </select>

                </div>
              </div>

              <div class="form-group">
                <label>Damage Type</label>

                <select id="cc-damage-type">
                  ${damageTypeOptionsHtml()}
                </select>
              </div>

            </div>

            <div class="form-group">

              <label>Effect Script</label>

              <textarea
                id="cc-script"
                rows="11"
                style="
                  width:100%;
                  font-family:monospace;
                "
                placeholder="// Example:
on startTurn
damage 1d6 fire"
              ></textarea>

              <div
                style="
                  display:flex;
                  gap:6px;
                  flex-wrap:wrap;
                  margin-top:6px;
                "
              >

                <button
                  id="cc-script-help"
                  type="button"
                >
                  <i class="fas fa-book-open"></i>
                  Script Commands
                </button>

                <button
                  id="cc-validate"
                  type="button"
                >
                  <i class="fas fa-check"></i>
                  Validate
                </button>

              </div>
            </div>

            <div class="form-group">
              <label>Linked Journal Page</label>

              <select id="cc-journal">
                ${journalPageOptionsHtml()}
              </select>
            </div>

            <div class="form-group">
              <label>
                <input
                  id="cc-auto-page"
                  type="checkbox"
                  checked
                />

                Automatically create a journal page
              </label>
            </div>

          </div>
        `,

        buttons: {
          create: {
            icon:
              '<i class="fas fa-plus"></i>',

            label:
              "Create",

            callback:
              async (html) => {
                const name =
                  String(
                    html.find(
                      "#cc-name"
                    ).val() ??
                    ""
                  ).trim();

                const script =
                  String(
                    html.find(
                      "#cc-script"
                    ).val() ??
                    ""
                  ).trim();

                if (!name) {
                  ui.notifications.warn(
                    "Condition name is required."
                  );

                  return false;
                }

                const validation =
                  validateConditionScript(
                    script
                  );

                if (
                  !validation.ok
                ) {
                  ui.notifications.error(
                    validation.errors[0]
                  );

                  console.warn(
                    `${MODULE_ID} | Script validation errors`,
                    validation.errors
                  );

                  return false;
                }

                try {
                  await requestGM(
                    "createCondition",
                    {
                      name,

                      icon:
                        String(
                          html.find(
                            "#cc-icon"
                          ).val() ||
                          "icons/svg/aura.svg"
                        ),

                      script,

                      journalUuid:
                        String(
                          html.find(
                            "#cc-journal"
                          ).val() ||
                          ""
                        ),

                      autoPage:
                        html.find(
                          "#cc-auto-page"
                        ).is(
                          ":checked"
                        )
                    }
                  );

                  ui.notifications.info(
                    `Created ${name}.`
                  );
                } catch (err) {
                  console.error(
                    err
                  );

                  ui.notifications.error(
                    err.message
                  );

                  return false;
                }
              }
          },

          close: {
            icon:
              '<i class="fas fa-times"></i>',

            label:
              "Close"
          }
        },

        render:
          (html) => {
            let updatingTemplate =
              false;

            const refreshTemplate =
              () => {
                const template =
                  html.find(
                    "#cc-template"
                  ).val();

                const damageTemplate =
                  template ===
                  "start-turn-damage";

                html.find(
                  "#cc-damage-template"
                ).toggle(
                  damageTemplate
                );

                if (
                  !damageTemplate
                ) {
                  return;
                }

                updatingTemplate =
                  true;

                html.find(
                  "#cc-script"
                ).val(
                  buildStartTurnDamageScript({
                    diceCount:
                      html.find(
                        "#cc-dice-count"
                      ).val(),

                    dieSize:
                      html.find(
                        "#cc-die-size"
                      ).val(),

                    damageType:
                      html.find(
                        "#cc-damage-type"
                      ).val()
                  })
                );

                updatingTemplate =
                  false;
              };

            html.find(
              "#cc-template"
            ).on(
              "change",
              refreshTemplate
            );

            html.find(
              "#cc-dice-count, #cc-die-size, #cc-damage-type"
            ).on(
              "input change",
              refreshTemplate
            );

            html.find(
              "#cc-script"
            ).on(
              "input",
              () => {
                if (
                  updatingTemplate
                ) {
                  return;
                }

                html.find(
                  "#cc-template"
                ).val(
                  "custom"
                );

                html.find(
                  "#cc-damage-template"
                ).hide();
              }
            );

            html.find(
              "#cc-script-help"
            ).on(
              "click",
              (event) => {
                event.preventDefault();

                openScriptHelp();
              }
            );

            html.find(
              "#cc-validate"
            ).on(
              "click",
              (event) => {
                event.preventDefault();

                const script =
                  String(
                    html.find(
                      "#cc-script"
                    ).val() ??
                    ""
                  );

                const result =
                  validateConditionScript(
                    script
                  );

                if (
                  result.ok
                ) {
                  ui.notifications.info(
                    "Script is valid."
                  );
                } else {
                  ui.notifications.error(
                    result.errors[0]
                  );

                  console.warn(
                    `${MODULE_ID} | Script validation errors`,
                    result.errors
                  );
                }
              }
            );

            html.find(
              "#cc-pick-icon"
            ).on(
              "click",
              (event) => {
                event.preventDefault();

                const input =
                  html.find(
                    "#cc-icon"
                  )[0];

                new FilePicker({
                  type:
                    "image",

                  current:
                    input.value ||
                    "icons/svg/",

                  callback:
                    (path) => {
                      input.value =
                        path;
                    }
                }).render(
                  true
                );
              }
            );

            html.find(
              ".cc-open-journal"
            ).on(
              "click",
              async (event) => {
                event.preventDefault();

                await openLinkedJournal(
                  event.currentTarget
                    .dataset
                    .uuid
                );
              }
            );

            html.find(
              ".cc-edit"
            ).on(
              "click",
              (event) => {
                event.preventDefault();

                const id =
                  event.currentTarget
                    .dataset
                    .id;

                const condition =
                  getConditions().find(
                    (entry) =>
                      entry.id === id
                  );

                if (!condition) {
                  return;
                }

                openEditConditionDialog(
                  condition
                );
              }
            );

            html.find(
              ".cc-delete"
            ).on(
              "click",
              async (event) => {
                event.preventDefault();

                const id =
                  event.currentTarget
                    .dataset
                    .id;

                try {
                  await requestGM(
                    "deleteCondition",
                    {
                      id
                    }
                  );

                  dialog.close();

                  setTimeout(
                    openConditionManager,
                    100
                  );
                } catch (err) {
                  ui.notifications.error(
                    err.message
                  );
                }
              }
            );

            refreshTemplate();
          },

        default:
          "create"
      },

      {
        width:
          520,

        height:
          "auto"
      }
    );

  dialog.render(
    true
  );
}


/* ============================================================ */
/* Edit Condition                                               */
/* ============================================================ */

function openEditConditionDialog(
  condition
) {
  const dialog =
    new Dialog(
      {
        title:
          `Edit Condition — ${condition.name}`,

        content: `
          <div class="cc-manager">

            <div class="form-group">
              <label>Name</label>

              <input
                id="cc-edit-name"
                type="text"
                value="${escapeHtml(
                  condition.name
                )}"
              />
            </div>

            <div class="form-group">
              <label>Icon</label>

              <div
                style="
                  display:flex;
                  gap:6px;
                "
              >
                <input
                  id="cc-edit-icon"
                  type="text"
                  value="${escapeHtml(
                    condition.icon ||
                    "icons/svg/aura.svg"
                  )}"
                  style="flex:1;"
                />

                <button
                  id="cc-edit-pick-icon"
                  type="button"
                  title="Choose icon"
                >
                  <i class="fas fa-image"></i>
                </button>
              </div>
            </div>

            <div class="form-group">

              <label>Effect Script</label>

              <textarea
                id="cc-edit-script"
                rows="15"
                style="
                  width:100%;
                  font-family:monospace;
                "
              >${escapeHtml(
                condition.script ||
                ""
              )}</textarea>

              <div
                style="
                  display:flex;
                  gap:6px;
                  flex-wrap:wrap;
                  margin-top:6px;
                "
              >

                <button
                  id="cc-edit-help"
                  type="button"
                >
                  <i class="fas fa-book-open"></i>
                  Script Commands
                </button>

                <button
                  id="cc-edit-validate"
                  type="button"
                >
                  <i class="fas fa-check"></i>
                  Validate
                </button>

              </div>

            </div>

            <div class="form-group">
              <label>Linked Journal Page</label>

              <select id="cc-edit-journal">
                ${journalPageOptionsHtml(
                  condition.journalUuid ||
                  ""
                )}
              </select>
            </div>

            <div class="form-group">

              <label>

                <input
                  id="cc-edit-auto-page"
                  type="checkbox"
                  ${
                    condition.journalUuid
                      ? ""
                      : "checked"
                  }
                />

                Create a journal page if none is linked

              </label>

            </div>

            <p class="notes">
              Saving preserves this condition's ID
              and current stack counts on creatures
              that already have it.
            </p>

          </div>
        `,

        buttons: {
          save: {
            icon:
              '<i class="fas fa-save"></i>',

            label:
              "Save Changes",

            callback:
              async (html) => {
                const name =
                  String(
                    html.find(
                      "#cc-edit-name"
                    ).val() ??
                    ""
                  ).trim();

                const script =
                  String(
                    html.find(
                      "#cc-edit-script"
                    ).val() ??
                    ""
                  ).trim();

                if (!name) {
                  ui.notifications.warn(
                    "Condition name is required."
                  );

                  return false;
                }

                const validation =
                  validateConditionScript(
                    script
                  );

                if (
                  !validation.ok
                ) {
                  ui.notifications.error(
                    validation.errors[0]
                  );

                  console.warn(
                    `${MODULE_ID} | Script validation errors`,
                    validation.errors
                  );

                  return false;
                }

                try {
                  await requestGM(
                    "updateCondition",
                    {
                      id:
                        condition.id,

                      name,

                      icon:
                        String(
                          html.find(
                            "#cc-edit-icon"
                          ).val() ||
                          "icons/svg/aura.svg"
                        ),

                      script,

                      journalUuid:
                        String(
                          html.find(
                            "#cc-edit-journal"
                          ).val() ||
                          ""
                        ),

                      autoPage:
                        html.find(
                          "#cc-edit-auto-page"
                        ).is(
                          ":checked"
                        )
                    }
                  );

                  ui.notifications.info(
                    `Updated ${name}.`
                  );

                  /*
                   * Refresh the manager so the edited
                   * name/icon appears there immediately.
                   */
                  setTimeout(
                    () => {
                      openConditionManager();
                    },
                    100
                  );
                } catch (err) {
                  console.error(
                    err
                  );

                  ui.notifications.error(
                    err.message ||
                    "Failed to update condition."
                  );

                  return false;
                }
              }
          },

          cancel: {
            icon:
              '<i class="fas fa-times"></i>',

            label:
              "Cancel"
          }
        },

        render:
          (html) => {
            html.find(
              "#cc-edit-help"
            ).on(
              "click",
              (event) => {
                event.preventDefault();

                openScriptHelp();
              }
            );

            html.find(
              "#cc-edit-validate"
            ).on(
              "click",
              (event) => {
                event.preventDefault();

                const script =
                  String(
                    html.find(
                      "#cc-edit-script"
                    ).val() ??
                    ""
                  );

                const result =
                  validateConditionScript(
                    script
                  );

                if (
                  result.ok
                ) {
                  ui.notifications.info(
                    "Script is valid."
                  );
                } else {
                  ui.notifications.error(
                    result.errors[0]
                  );

                  console.warn(
                    `${MODULE_ID} | Script validation errors`,
                    result.errors
                  );
                }
              }
            );

            html.find(
              "#cc-edit-pick-icon"
            ).on(
              "click",
              (event) => {
                event.preventDefault();

                const input =
                  html.find(
                    "#cc-edit-icon"
                  )[0];

                new FilePicker({
                  type:
                    "image",

                  current:
                    input.value ||
                    "icons/svg/",

                  callback:
                    (path) => {
                      input.value =
                        path;
                    }
                }).render(
                  true
                );
              }
            );
          },

        default:
          "save"
      },

      {
        width:
          570,

        height:
          "auto"
      }
    );

  dialog.render(
    true
  );
}


/* ============================================================ */
/* Apply Condition Dialog                                       */
/* ============================================================ */

function openApplyConditionDialog(
  token
) {
  const conditions =
    getConditions();

  if (!conditions.length) {
    ui.notifications.warn(
      "No custom conditions have been created."
    );

    return;
  }

  const options =
    conditions
      .map(
        (condition) => {
          const stacks =
            getConditionStacksOnActor(
              token.actor,
              condition.id
            );

          const label =
            stacks !== null &&
            stacks > 0
              ? (
                `${condition.name} ` +
                `[${stacks} stack` +
                `${stacks === 1 ? "" : "s"}]`
              )
              : condition.name;

          return (
            `<option value="${escapeHtml(
              condition.id
            )}">` +
            `${escapeHtml(label)}` +
            `</option>`
          );
        }
      )
      .join("");

  const dialog =
    new Dialog(
      {
        title:
          `Apply Condition — ${token.name}`,

        content: `
          <div class="form-group">

            <label>Condition</label>

            <select id="cc-condition">
              ${options}
            </select>

          </div>

          <div
            id="cc-stack-info"
            class="notes"
            style="margin-top:6px;"
          ></div>

          <div
            style="
              display:flex;
              gap:6px;
              flex-wrap:wrap;
              margin-top:8px;
            "
          >

            <button
              id="cc-stack-minus"
              type="button"
              title="Remove one stack"
            >
              <i class="fas fa-minus"></i>
              Stack
            </button>

            <button
              id="cc-stack-plus"
              type="button"
              title="Add one stack"
            >
              <i class="fas fa-plus"></i>
              Stack
            </button>

            <button
              id="cc-open-rules"
              type="button"
            >
              <i class="fas fa-book"></i>
              Open Rules Journal
            </button>

          </div>

          <p
            class="notes"
            style="margin-top:8px;"
          >
            Apply / Toggle adds the condition if absent,
            or removes it if already present.
          </p>
        `,

        buttons: {
          apply: {
            icon:
              '<i class="fas fa-check"></i>',

            label:
              "Apply / Toggle",

            callback:
              async (html) => {
                const id =
                  html.find(
                    "#cc-condition"
                  ).val();

                const condition =
                  conditions.find(
                    (entry) =>
                      entry.id === id
                  );

                if (condition) {
                  await toggleConditionOnToken(
                    token,
                    condition
                  );
                }
              }
          },

          cancel: {
            icon:
              '<i class="fas fa-times"></i>',

            label:
              "Cancel"
          }
        },

        render:
          (html) => {
            const selectedCondition =
              () => {
                const id =
                  html.find(
                    "#cc-condition"
                  ).val();

                return (
                  conditions.find(
                    (entry) =>
                      entry.id === id
                  ) ??
                  null
                );
              };

            const refreshStackInfo =
              () => {
                const condition =
                  selectedCondition();

                if (!condition) {
                  return;
                }

                const stacks =
                  getConditionStacksOnActor(
                    token.actor,
                    condition.id
                  );

                const active =
                  stacks !== null;

                html.find(
                  "#cc-stack-info"
                ).text(
                  active
                    ? (
                      `Currently active with ` +
                      `${stacks} stack` +
                      `${stacks === 1 ? "" : "s"}.`
                    )
                    : (
                      "This condition is not currently active."
                    )
                );

                html.find(
                  "#cc-stack-plus, #cc-stack-minus"
                ).prop(
                  "disabled",
                  !active
                );
              };

            html.find(
              "#cc-condition"
            ).on(
              "change",
              refreshStackInfo
            );

            html.find(
              "#cc-open-rules"
            ).on(
              "click",
              async (event) => {
                event.preventDefault();

                await openLinkedJournal(
                  selectedCondition()
                    ?.journalUuid
                );
              }
            );

            html.find(
              "#cc-stack-plus"
            ).on(
              "click",
              async (event) => {
                event.preventDefault();

                const condition =
                  selectedCondition();

                if (!condition) {
                  return;
                }

                const effect =
                  findConditionEffect(
                    token.actor,
                    condition.id
                  );

                if (!effect) {
                  return;
                }

                const current =
                  Math.max(
                    0,
                    Number(
                      effect.getFlag(
                        MODULE_ID,
                        "stacks"
                      ) ?? 0
                    )
                  );

                await setEffectStacksManually(
                  effect,
                  condition,
                  current + 1
                );

                refreshStackInfo();
              }
            );

            html.find(
              "#cc-stack-minus"
            ).on(
              "click",
              async (event) => {
                event.preventDefault();

                const condition =
                  selectedCondition();

                if (!condition) {
                  return;
                }

                const effect =
                  findConditionEffect(
                    token.actor,
                    condition.id
                  );

                if (!effect) {
                  return;
                }

                const current =
                  Math.max(
                    0,
                    Number(
                      effect.getFlag(
                        MODULE_ID,
                        "stacks"
                      ) ?? 0
                    )
                  );

                await setEffectStacksManually(
                  effect,
                  condition,
                  Math.max(
                    0,
                    current - 1
                  )
                );

                refreshStackInfo();
              }
            );

            refreshStackInfo();
          },

        default:
          "apply"
      },

      {
        width:
          470
      }
    );

  dialog.render(
    true
  );
}


/* ============================================================ */
/* Manual stack changes                                         */
/* ============================================================ */

async function setEffectStacksManually(
  effect,
  condition,
  stacks
) {
  const baseName =
    effect.getFlag(
      MODULE_ID,
      "baseName"
    ) ||
    condition.name ||
    String(
      effect.name ??
      "Condition"
    ).replace(
      /\s+\[\d+\]$/,
      ""
    );

  const name =
    stacks > 0
      ? `${baseName} [${stacks}]`
      : baseName;

  await effect.update({
    name,

    [`flags.${MODULE_ID}.stacks`]:
      stacks,

    [`flags.${MODULE_ID}.baseName`]:
      baseName
  });

  /*
   * Re-run the apply section so persistent
   * modifiers such as ac +@stack and
   * saveDC +@stack are recalculated.
   *
   * This does mean other "on apply" commands
   * would also run, so instead of executing
   * the whole section we use the scripting
   * engine's modifier refresh through the
   * public stack-change path below.
   */
  await runConditionScript({
    actor:
      effect.parent,

    effect,

    condition,

    trigger:
      "stackChange"
  });
}


/* ============================================================ */
/* Toggle condition                                             */
/* ============================================================ */

async function toggleConditionOnToken(
  token,
  condition
) {
  const actor =
    token.actor;

  if (!actor) {
    return;
  }

  const existing =
    findConditionEffect(
      actor,
      condition.id
    );

  if (existing) {
    await existing.delete();

    ui.notifications.info(
      `Removed ${condition.name} from ${actor.name}.`
    );

    return;
  }

  await createConditionEffect(
    actor,
    condition
  );

  ui.notifications.info(
    `Applied ${condition.name} to ${actor.name}.`
  );
}


/* ============================================================ */
/* Active Effect hooks                                          */
/* ============================================================ */

Hooks.on(
  "preCreateActiveEffect",
  (
    effect,
    data
  ) => {
    try {
      const statuses =
        new Set(
          data?.statuses ??
          effect?.statuses ??
          []
        );

      if (
        !statuses.size
      ) {
        return;
      }

      const condition =
        getConditions().find(
          (entry) =>
            statuses.has(
              entry.id
            )
        );

      if (!condition) {
        return;
      }

      effect.updateSource({
        [`flags.${MODULE_ID}.conditionId`]:
          condition.id,

        [`flags.${MODULE_ID}.script`]:
          condition.script ||
          "",

        [`flags.${MODULE_ID}.stacks`]:
          0,

        [`flags.${MODULE_ID}.baseName`]:
          condition.name,

        [`flags.${MODULE_ID}.journalUuid`]:
          condition.journalUuid ||
          null
      });
    } catch (err) {
      console.warn(
        `${MODULE_ID} | Failed to stamp ActiveEffect flags`,
        err
      );
    }
  }
);


Hooks.on(
  "createActiveEffect",
  (effect) => {
    if (!isActiveGM()) {
      return;
    }

    const condition =
      resolveConditionForEffect(
        effect
      );

    if (!condition) {
      return;
    }

    const actor =
      effect.parent;

    if (
      actor?.documentName !==
      "Actor"
    ) {
      return;
    }

    void runConditionScript({
      actor,
      effect,
      condition,

      trigger:
        "apply"
    });
  }
);


Hooks.on(
  "deleteActiveEffect",
  (effect) => {
    if (!isActiveGM()) {
      return;
    }

    const condition =
      resolveConditionForEffect(
        effect
      );

    if (!condition) {
      return;
    }

    const actor =
      effect.parent;

    if (!actor) {
      return;
    }

    void runConditionScript({
      actor,
      effect,
      condition,

      trigger:
        "remove"
    });
  }
);


/* ============================================================ */
/* Combat automation                                            */
/* ============================================================ */

const processedTransitions =
  new Map();

const lastCombatStates =
  new Map();


function normalizeCombatState(
  combat,
  state = null
) {
  const source =
    state ?? {};

  const combatantId =
    source.combatantId ??
    combat?.combatant?.id ??
    null;

  return {
    round:
      source.round ??
      combat?.round ??
      null,

    turn:
      source.turn ??
      combat?.turn ??
      null,

    combatantId
  };
}


function combatStateKey(
  state
) {
  return (
    `${state?.round ?? "x"}:` +
    `${state?.turn ?? "x"}:` +
    `${state?.combatantId ?? "x"}`
  );
}


async function runCombatantTrigger(
  combatant,
  trigger
) {
  if (!combatant) {
    return;
  }

  const token =
    combatant.token ??
    null;

  /*
   * Prefer synthetic token actor.
   */
  const actor =
    token?.actor ??
    combatant.actor ??
    null;

  if (!actor) {
    return;
  }

  const conditions =
    getConditions();

  const effects =
    Array.from(
      actor.effects ??
      []
    );

  for (
    const effect of effects
  ) {
    if (
      effect.disabled ||
      effect.isSuppressed ||
      effect.active === false
    ) {
      continue;
    }

    const condition =
      resolveConditionForEffect(
        effect,
        conditions
      );

    if (!condition) {
      continue;
    }

    await runConditionScript({
      actor,
      token,
      effect,
      condition,
      trigger
    });
  }
}


async function processCombatTransition(
  combat,
  previous,
  current,
  source = "unknown"
) {
  if (
    !isActiveGM() ||
    !combat
  ) {
    return;
  }

  const oldState =
    normalizeCombatState(
      combat,
      previous
    );

  const newState =
    normalizeCombatState(
      combat,
      current
    );

  if (
    combatStateKey(
      oldState
    ) ===
    combatStateKey(
      newState
    )
  ) {
    lastCombatStates.set(
      combat.id,
      newState
    );

    return;
  }

  const transitionKey =
    `${combatStateKey(
      oldState
    )}>${combatStateKey(
      newState
    )}`;

  /*
   * Avoid duplicate start/end processing
   * if both combat hooks report the
   * same change.
   */
  if (
    processedTransitions.get(
      combat.id
    ) ===
    transitionKey
  ) {
    lastCombatStates.set(
      combat.id,
      newState
    );

    return;
  }

  processedTransitions.set(
    combat.id,
    transitionKey
  );

  lastCombatStates.set(
    combat.id,
    newState
  );

  console.log(
    `${MODULE_ID} | Combat transition via ${source}: ${transitionKey}`
  );

  /*
   * Previous creature ends turn.
   */
  if (
    oldState.combatantId
  ) {
    const previousCombatant =
      combat.combatants.get(
        oldState.combatantId
      );

    if (
      previousCombatant
    ) {
      await runCombatantTrigger(
        previousCombatant,
        "endTurn"
      );
    }
  }

  /*
   * New creature starts turn.
   */
  if (
    newState.combatantId
  ) {
    const currentCombatant =
      combat.combatants.get(
        newState.combatantId
      );

    if (
      currentCombatant
    ) {
      await runCombatantTrigger(
        currentCombatant,
        "startTurn"
      );
    }
  }
}


/*
 * Primary Foundry v13 hook.
 */
Hooks.on(
  "combatTurnChange",
  (
    combat,
    previous,
    current
  ) => {
    void processCombatTransition(
      combat,
      previous,
      current,
      "combatTurnChange"
    );
  }
);


/*
 * Fallback.
 */
Hooks.on(
  "updateCombat",
  (
    combat,
    changed
  ) => {
    if (
      !Object.hasOwn(
        changed,
        "round"
      ) &&
      !Object.hasOwn(
        changed,
        "turn"
      )
    ) {
      return;
    }

    const previous =
      lastCombatStates.get(
        combat.id
      ) ??
      combat.previous ??
      null;

    setTimeout(
      () => {
        const current =
          normalizeCombatState(
            combat,
            combat.current
          );

        void processCombatTransition(
          combat,
          previous,
          current,
          "updateCombat"
        );
      },
      0
    );
  }
);


Hooks.on(
  "deleteCombat",
  (combat) => {
    processedTransitions.delete(
      combat.id
    );

    lastCombatStates.delete(
      combat.id
    );
  }
);


/* ============================================================ */
/* Debug / macro API                                            */
/* ============================================================ */

function exposeApi() {
  const module =
    game.modules.get(
      MODULE_ID
    );

  if (!module) {
    return;
  }

  module.api = {
    getConditions,

    validateScript:
      validateConditionScript,

    openScriptHelp,

    openManager:
      openConditionManager,

    async runCurrentTurn() {
      if (
        !isActiveGM()
      ) {
        throw new Error(
          "Only the active GM runs condition automation."
        );
      }

      const combat =
        game.combat;

      if (
        !combat?.started
      ) {
        throw new Error(
          "No active combat."
        );
      }

      if (
        !combat.combatant
      ) {
        throw new Error(
          "No current combatant."
        );
      }

      await runCombatantTrigger(
        combat.combatant,
        "startTurn"
      );
    }
  };
}